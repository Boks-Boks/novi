﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <stdint.h>
#include <limits>



// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARAnchor>
struct List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.AREnvironmentProbe>
struct List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARFace>
struct List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARHumanBody>
struct List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARParticipant>
struct List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPlane>
struct List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPointCloud>
struct List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARReferencePoint>
struct List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedImage>
struct List_1_tFA730335FF46512E4245B2F46892CA318B394FAE;
// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedObject>
struct List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73;
// System.Collections.Generic.List`1<UnityEngine.MeshFilter>
struct List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930;
// System.Collections.Generic.List`1<System.String>
struct List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD;
// System.Collections.Generic.List`1<UnityEngine.Texture2D>
struct List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4;
// System.Collections.Generic.List`1<UnityEngine.XR.XRInputSubsystem>
struct List_1_t90832B88D7207769654164CC28440CF594CC397D;
// System.Collections.Generic.List`1<UnityEngine.XR.ARSubsystems.XRReferenceObjectEntry>
struct List_1_tC0E7595725AFEF62394C64B77712190FBAC6C2C5;
// System.Collections.Generic.List`1<UnityEngine.SpatialTracking.TrackedPoseDriver/TrackedPose>
struct List_1_t8A06DB5554CD76CE072807DE6EF4198109D84E53;
// System.Byte[][]
struct ByteU5BU5DU5BU5D_t19A0C6D66F22DF673E9CDB37DEF566FE0EC947FA;
// System.Char[][]
struct CharU5BU5DU5BU5D_tE6ABF380CD3BBDBB52C3EF725A02224F2B4AA680;
// System.Int32[][]
struct Int32U5BU5DU5BU5D_t179D865D5B30EFCBC50F82C9774329C15943466E;
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
// UnityEngine.XR.ARFoundation.ARFace
struct ARFace_t73C068C9C8422F79A858EC41C322D399305B8453;
// UnityEngine.XR.ARFoundation.ARPlane
struct ARPlane_tB2F02248AD4019D141553B25C1B9005913E98EF0;
// UnityEngine.XR.ARFoundation.ARRaycast
struct ARRaycast_t141143E16F40B1580060317DA867423FF2624E76;
// UnityEngine.XR.ARFoundation.ARSessionOrigin
struct ARSessionOrigin_tE7B28A1A19500BCC02711397A19E330425830BC3;
// UnityEngine.XR.ARFoundation.ARTrackable
struct ARTrackable_t1D98417758C08E98A333CDEC0C2C1688CE10B2E0;
// System.Byte
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3;
// System.Threading.ManualResetEvent
struct ManualResetEvent_t63959486AA41A113A4353D0BF4A68E77EBA0A158;
// System.Reflection.MemberInfo
struct MemberInfo_t;
// UnityEngine.Mesh
struct Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4;
// UnityEngine.MeshCollider
struct MeshCollider_tB525E4DDE383252364ED0BDD32CF2B53914EE455;
// UnityEngine.XR.ARSubsystems.MutableRuntimeReferenceImageLibrary
struct MutableRuntimeReferenceImageLibrary_t51AE6E77B281FCE9DF42C7E905A11935708A53F8;
// System.Text.RegularExpressions.Regex
struct Regex_tE773142C2BE45C5D362B0F815AFF831707A51772;
// UnityEngine.RenderTexture
struct RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27;
// System.Threading.SendOrPostCallback
struct SendOrPostCallback_t5C292A12062F24027A98492F52ECFE9802AA6F0E;
// System.String
struct String_t;
// UnityEngine.Texture
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700;
// UnityEngine.Texture2D
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
// UnityEngine.Transform
struct Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1;
// System.Type
struct Type_t;
// UnityEngine.Events.UnityAction
struct UnityAction_t11A1F3B953B365C072A5DCC32677EE1796A962A7;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
// UnityEngine.XR.ARSubsystems.XRCpuImage/Api
struct Api_tAE210A8378E537AFD1FA4B99562229CE842377FB;
// UnityEngine.XR.ARSubsystems.XRCpuImage/Api/OnImageRequestCompleteDelegate
struct OnImageRequestCompleteDelegate_tCD7B27E0C5D492FB984F05869FB527372CB70995;



IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// System.Collections.Generic.KeyValuePair`2<System.Byte[][],System.Object>
struct KeyValuePair_2_t8E0D15B87910CDDA42560D1A46FD995D80D1210F 
{
	// TKey System.Collections.Generic.KeyValuePair`2::key
	ByteU5BU5DU5BU5D_t19A0C6D66F22DF673E9CDB37DEF566FE0EC947FA* ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject* ___value_1;
};

// System.Collections.Generic.KeyValuePair`2<System.Char[][],System.Object>
struct KeyValuePair_2_tA15A2CDE2D0067F592CD9373418E53A418842273 
{
	// TKey System.Collections.Generic.KeyValuePair`2::key
	CharU5BU5DU5BU5D_tE6ABF380CD3BBDBB52C3EF725A02224F2B4AA680* ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject* ___value_1;
};

// System.Collections.Generic.KeyValuePair`2<System.Int32[][],System.Object>
struct KeyValuePair_2_tFA55EACE445F07ED0E758AB6E024B85AB8FD089D 
{
	// TKey System.Collections.Generic.KeyValuePair`2::key
	Int32U5BU5DU5BU5D_t179D865D5B30EFCBC50F82C9774329C15943466E* ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject* ___value_1;
};

// System.Collections.Generic.KeyValuePair`2<System.Object,System.Object>
struct KeyValuePair_2_tFC32D2507216293851350D29B64D79F950B55230 
{
	// TKey System.Collections.Generic.KeyValuePair`2::key
	RuntimeObject* ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject* ___value_1;
};

// Unity.Collections.NativeArray`1<UnityEngine.Rendering.BatchCullingOutputDrawCommands>
struct NativeArray_1_tBEE3484B4ABC271CFAB65039F1439061D5DF806A 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.BoundedPlane>
struct NativeArray_1_t36CA775B66FDBC3A63AF9ABB6E32E8F6B41F824C 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<System.Byte>
struct NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.ConfigurationDescriptor>
struct NativeArray_1_t280B4C6187922FE73AC16AC7F23255AE192676E2 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.Rendering.CullingSplit>
struct NativeArray_1_t73992261AA60020B6BE20D83C50B3F925CC89F31 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.Experimental.GlobalIllumination.LightDataGI>
struct NativeArray_1_tDF6A1978B5813BF4DAD7948E398009FFC9BEA38D 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.ModifiableContactPair>
struct NativeArray_1_tA04FF6E7BE3D24B3E6351C63BF7229421DFE1259 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.Plane>
struct NativeArray_1_t4020B6981295FB915DCE82EF368535F680C13A49 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<System.Single>
struct NativeArray_1_t3848EE4B6647317212A754634DE6DBC90B99FBEF 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId>
struct NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<System.UInt64>
struct NativeArray_1_t07975297AD7F7512193094A7C0703BA872EF7A7B 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.Vector3>
struct NativeArray_1_t97E2BFD61E13EEF2CDE34A313415FAD03AB993FD 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRAnchor>
struct NativeArray_1_tAE2F2F17B6A4F98F44324897A00F6A9D2151DC3A 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRCameraConfiguration>
struct NativeArray_1_tAE1C2CA4717E405609ED9F96E485A9FE00E622D6 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XREnvironmentProbe>
struct NativeArray_1_t27110FD746D2F878E09169A93400CE1027082DA2 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRFace>
struct NativeArray_1_t944085523DA105D6BBD308E9159C874CE60B3009 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRHumanBody>
struct NativeArray_1_t5B6781386C81B6DAD0A46599F36186F644DC17D0 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRHumanBodyPose2DJoint>
struct NativeArray_1_t4998E9C3FBA8DDD4E076225A6D136D48D0C25386 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRParticipant>
struct NativeArray_1_t79743910830B59034ED2B060D4E1D0EC70226E18 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRPointCloud>
struct NativeArray_1_t50096787A7C7D874EC2A53B03F61419BE240D9C0 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRRaycast>
struct NativeArray_1_t43267D13364B938F522273E473A86557B971CD63 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRRaycastHit>
struct NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRReferencePoint>
struct NativeArray_1_t25DC732E6C086A8D9E0F2322692DDD67260AF33B 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRTextureDescriptor>
struct NativeArray_1_t6C2613A1D4A03EFEE59BBADBC529386D1205D01C 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRTrackedImage>
struct NativeArray_1_tC503E651BA1B71B961BBC7485E923DD431EFCC66 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.XRTrackedObject>
struct NativeArray_1_t0F4B76D476AFCD1C3D325B2AF615317AF55BE50B 
{
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;
};

// Unity.Collections.NativeSlice`1<System.Byte>
struct NativeSlice_1_tCEC4B2B900638EC1820BB61FE436766204DFD8DA 
{
	// System.Byte* Unity.Collections.NativeSlice`1::m_Buffer
	uint8_t* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeSlice`1::m_Stride
	int32_t ___m_Stride_1;
	// System.Int32 Unity.Collections.NativeSlice`1::m_Length
	int32_t ___m_Length_2;
};

// Unity.Collections.NativeSlice`1<UnityEngine.XR.ARSubsystems.ConfigurationDescriptor>
struct NativeSlice_1_t398BDCDCE5F9AF840285A8E6EC69152FED8FADFE 
{
	// System.Byte* Unity.Collections.NativeSlice`1::m_Buffer
	uint8_t* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeSlice`1::m_Stride
	int32_t ___m_Stride_1;
	// System.Int32 Unity.Collections.NativeSlice`1::m_Length
	int32_t ___m_Length_2;
};

// System.Nullable`1<System.Double>
struct Nullable_1_t6E154519A812D040E3016229CD7638843A2CC165 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	double ___value_1;
};

// System.Nullable`1<System.Int32>
struct Nullable_1_tCF32C56A2641879C053C86F273C0C6EC1B40BC28 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	int32_t ___value_1;
};

// System.Nullable`1<System.Int64>
struct Nullable_1_t365991B3904FDA7642A788423B28692FDC7CDB17 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	int64_t ___value_1;
};

// System.Nullable`1<System.Single>
struct Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	float ___value_1;
};

// System.ValueTuple`2<System.Object,System.Object>
struct ValueTuple_2_tC3717D4552EE1E5FC27BFBA3F5155741BC04557A 
{
	// T1 System.ValueTuple`2::Item1
	RuntimeObject* ___Item1_0;
	// T2 System.ValueTuple`2::Item2
	RuntimeObject* ___Item2_1;
};

// System.ValueTuple`3<System.Object,System.Int32,System.Int32>
struct ValueTuple_3_tFD2ADB3DA89E958885034AAFEF1ABDA8C814D987 
{
	// T1 System.ValueTuple`3::Item1
	RuntimeObject* ___Item1_0;
	// T2 System.ValueTuple`3::Item2
	int32_t ___Item2_1;
	// T3 System.ValueTuple`3::Item3
	int32_t ___Item3_2;
};

// UnityEngine.XR.ARFoundation.ARAnchorsChangedEventArgs
struct ARAnchorsChangedEventArgs_t755E6208C84304CAC448C133B0A8660CD5750A75 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARAnchor> UnityEngine.XR.ARFoundation.ARAnchorsChangedEventArgs::<added>k__BackingField
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARAnchor> UnityEngine.XR.ARFoundation.ARAnchorsChangedEventArgs::<updated>k__BackingField
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARAnchor> UnityEngine.XR.ARFoundation.ARAnchorsChangedEventArgs::<removed>k__BackingField
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARAnchorsChangedEventArgs
struct ARAnchorsChangedEventArgs_t755E6208C84304CAC448C133B0A8660CD5750A75_marshaled_pinvoke
{
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CaddedU3Ek__BackingField_0;
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARAnchorsChangedEventArgs
struct ARAnchorsChangedEventArgs_t755E6208C84304CAC448C133B0A8660CD5750A75_marshaled_com
{
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CaddedU3Ek__BackingField_0;
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t5C2EBF017989E44F3D1D11AF502E10F6F8D9AB53* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.AREnvironmentProbesChangedEvent
struct AREnvironmentProbesChangedEvent_t8757E98E11F3D37F0CFC4589FCA5CD2107F8375C 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.AREnvironmentProbe> UnityEngine.XR.ARFoundation.AREnvironmentProbesChangedEvent::<added>k__BackingField
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.AREnvironmentProbe> UnityEngine.XR.ARFoundation.AREnvironmentProbesChangedEvent::<updated>k__BackingField
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.AREnvironmentProbe> UnityEngine.XR.ARFoundation.AREnvironmentProbesChangedEvent::<removed>k__BackingField
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.AREnvironmentProbesChangedEvent
struct AREnvironmentProbesChangedEvent_t8757E98E11F3D37F0CFC4589FCA5CD2107F8375C_marshaled_pinvoke
{
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CaddedU3Ek__BackingField_0;
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.AREnvironmentProbesChangedEvent
struct AREnvironmentProbesChangedEvent_t8757E98E11F3D37F0CFC4589FCA5CD2107F8375C_marshaled_com
{
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CaddedU3Ek__BackingField_0;
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t6F14EE6179A9A8E042C5D65E902F72E24597029B* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARFaceUpdatedEventArgs
struct ARFaceUpdatedEventArgs_tC20D17255858678A1A8230EA32D7C38287221FF6 
{
	// UnityEngine.XR.ARFoundation.ARFace UnityEngine.XR.ARFoundation.ARFaceUpdatedEventArgs::<face>k__BackingField
	ARFace_t73C068C9C8422F79A858EC41C322D399305B8453* ___U3CfaceU3Ek__BackingField_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARFaceUpdatedEventArgs
struct ARFaceUpdatedEventArgs_tC20D17255858678A1A8230EA32D7C38287221FF6_marshaled_pinvoke
{
	ARFace_t73C068C9C8422F79A858EC41C322D399305B8453* ___U3CfaceU3Ek__BackingField_0;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARFaceUpdatedEventArgs
struct ARFaceUpdatedEventArgs_tC20D17255858678A1A8230EA32D7C38287221FF6_marshaled_com
{
	ARFace_t73C068C9C8422F79A858EC41C322D399305B8453* ___U3CfaceU3Ek__BackingField_0;
};

// UnityEngine.XR.ARFoundation.ARFacesChangedEventArgs
struct ARFacesChangedEventArgs_tC05D4423CB2096FF5955C3A0A00056EE2B6301AE 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARFace> UnityEngine.XR.ARFoundation.ARFacesChangedEventArgs::<added>k__BackingField
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARFace> UnityEngine.XR.ARFoundation.ARFacesChangedEventArgs::<updated>k__BackingField
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARFace> UnityEngine.XR.ARFoundation.ARFacesChangedEventArgs::<removed>k__BackingField
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARFacesChangedEventArgs
struct ARFacesChangedEventArgs_tC05D4423CB2096FF5955C3A0A00056EE2B6301AE_marshaled_pinvoke
{
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CaddedU3Ek__BackingField_0;
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARFacesChangedEventArgs
struct ARFacesChangedEventArgs_tC05D4423CB2096FF5955C3A0A00056EE2B6301AE_marshaled_com
{
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CaddedU3Ek__BackingField_0;
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tA11EBED64210DD13BB4303415D948E6CD964AAF9* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARHumanBodiesChangedEventArgs
struct ARHumanBodiesChangedEventArgs_t19088E0D3384A22C5D8A542957705222C834720B 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARHumanBody> UnityEngine.XR.ARFoundation.ARHumanBodiesChangedEventArgs::<added>k__BackingField
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARHumanBody> UnityEngine.XR.ARFoundation.ARHumanBodiesChangedEventArgs::<updated>k__BackingField
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARHumanBody> UnityEngine.XR.ARFoundation.ARHumanBodiesChangedEventArgs::<removed>k__BackingField
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARHumanBodiesChangedEventArgs
struct ARHumanBodiesChangedEventArgs_t19088E0D3384A22C5D8A542957705222C834720B_marshaled_pinvoke
{
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CaddedU3Ek__BackingField_0;
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARHumanBodiesChangedEventArgs
struct ARHumanBodiesChangedEventArgs_t19088E0D3384A22C5D8A542957705222C834720B_marshaled_com
{
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CaddedU3Ek__BackingField_0;
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t64B1B4ABB789350AE017F3EAF4D3647AF59244C7* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARMeshesChangedEventArgs
struct ARMeshesChangedEventArgs_tE7A52D1E319626788F0990029A19823C3FA83903 
{
	// System.Collections.Generic.List`1<UnityEngine.MeshFilter> UnityEngine.XR.ARFoundation.ARMeshesChangedEventArgs::<added>k__BackingField
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.MeshFilter> UnityEngine.XR.ARFoundation.ARMeshesChangedEventArgs::<updated>k__BackingField
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.MeshFilter> UnityEngine.XR.ARFoundation.ARMeshesChangedEventArgs::<removed>k__BackingField
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARMeshesChangedEventArgs
struct ARMeshesChangedEventArgs_tE7A52D1E319626788F0990029A19823C3FA83903_marshaled_pinvoke
{
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CaddedU3Ek__BackingField_0;
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARMeshesChangedEventArgs
struct ARMeshesChangedEventArgs_tE7A52D1E319626788F0990029A19823C3FA83903_marshaled_com
{
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CaddedU3Ek__BackingField_0;
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tF38D1A45CF65189578ADAC12AED34802EB2B8930* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs
struct AROcclusionFrameEventArgs_t50615B48D249629849B4157545F18620A4304E81 
{
	// System.Collections.Generic.List`1<UnityEngine.Texture2D> UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs::<textures>k__BackingField
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___U3CtexturesU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<System.Int32> UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs::<propertyNameIds>k__BackingField
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3CpropertyNameIdsU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<System.String> UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs::<enabledMaterialKeywords>k__BackingField
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CenabledMaterialKeywordsU3Ek__BackingField_2;
	// System.Collections.Generic.List`1<System.String> UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs::<disabledMaterialKeywords>k__BackingField
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CdisabledMaterialKeywordsU3Ek__BackingField_3;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs
struct AROcclusionFrameEventArgs_t50615B48D249629849B4157545F18620A4304E81_marshaled_pinvoke
{
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___U3CtexturesU3Ek__BackingField_0;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3CpropertyNameIdsU3Ek__BackingField_1;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CenabledMaterialKeywordsU3Ek__BackingField_2;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CdisabledMaterialKeywordsU3Ek__BackingField_3;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.AROcclusionFrameEventArgs
struct AROcclusionFrameEventArgs_t50615B48D249629849B4157545F18620A4304E81_marshaled_com
{
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___U3CtexturesU3Ek__BackingField_0;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3CpropertyNameIdsU3Ek__BackingField_1;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CenabledMaterialKeywordsU3Ek__BackingField_2;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CdisabledMaterialKeywordsU3Ek__BackingField_3;
};

// UnityEngine.XR.ARFoundation.ARParticipantsChangedEventArgs
struct ARParticipantsChangedEventArgs_t2EAD9041A074A7ACEFF280662784747A4E85E527 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARParticipant> UnityEngine.XR.ARFoundation.ARParticipantsChangedEventArgs::<added>k__BackingField
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARParticipant> UnityEngine.XR.ARFoundation.ARParticipantsChangedEventArgs::<updated>k__BackingField
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARParticipant> UnityEngine.XR.ARFoundation.ARParticipantsChangedEventArgs::<removed>k__BackingField
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARParticipantsChangedEventArgs
struct ARParticipantsChangedEventArgs_t2EAD9041A074A7ACEFF280662784747A4E85E527_marshaled_pinvoke
{
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CaddedU3Ek__BackingField_0;
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARParticipantsChangedEventArgs
struct ARParticipantsChangedEventArgs_t2EAD9041A074A7ACEFF280662784747A4E85E527_marshaled_com
{
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CaddedU3Ek__BackingField_0;
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t87D9AC2D6B4A4860E01575669DEB0D164D4B33B3* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARPlaneBoundaryChangedEventArgs
struct ARPlaneBoundaryChangedEventArgs_tE59EDE94575C8947AD3F1F8DA1370D0A426A5FFC 
{
	// UnityEngine.XR.ARFoundation.ARPlane UnityEngine.XR.ARFoundation.ARPlaneBoundaryChangedEventArgs::<plane>k__BackingField
	ARPlane_tB2F02248AD4019D141553B25C1B9005913E98EF0* ___U3CplaneU3Ek__BackingField_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARPlaneBoundaryChangedEventArgs
struct ARPlaneBoundaryChangedEventArgs_tE59EDE94575C8947AD3F1F8DA1370D0A426A5FFC_marshaled_pinvoke
{
	ARPlane_tB2F02248AD4019D141553B25C1B9005913E98EF0* ___U3CplaneU3Ek__BackingField_0;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARPlaneBoundaryChangedEventArgs
struct ARPlaneBoundaryChangedEventArgs_tE59EDE94575C8947AD3F1F8DA1370D0A426A5FFC_marshaled_com
{
	ARPlane_tB2F02248AD4019D141553B25C1B9005913E98EF0* ___U3CplaneU3Ek__BackingField_0;
};

// UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs
struct ARPlanesChangedEventArgs_t8D63E0257BF9942EF8F8C0445F2FD46421017872 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPlane> UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs::<added>k__BackingField
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPlane> UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs::<updated>k__BackingField
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPlane> UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs::<removed>k__BackingField
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs
struct ARPlanesChangedEventArgs_t8D63E0257BF9942EF8F8C0445F2FD46421017872_marshaled_pinvoke
{
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CaddedU3Ek__BackingField_0;
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARPlanesChangedEventArgs
struct ARPlanesChangedEventArgs_t8D63E0257BF9942EF8F8C0445F2FD46421017872_marshaled_com
{
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CaddedU3Ek__BackingField_0;
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t10BA05B555C92BD54800DFF82DCAAFC9DE44A077* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARPointCloudChangedEventArgs
struct ARPointCloudChangedEventArgs_t7DE4CA4D30D369496221061F89CC4BF84E42CC1B 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPointCloud> UnityEngine.XR.ARFoundation.ARPointCloudChangedEventArgs::<added>k__BackingField
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPointCloud> UnityEngine.XR.ARFoundation.ARPointCloudChangedEventArgs::<updated>k__BackingField
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARPointCloud> UnityEngine.XR.ARFoundation.ARPointCloudChangedEventArgs::<removed>k__BackingField
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARPointCloudChangedEventArgs
struct ARPointCloudChangedEventArgs_t7DE4CA4D30D369496221061F89CC4BF84E42CC1B_marshaled_pinvoke
{
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CaddedU3Ek__BackingField_0;
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARPointCloudChangedEventArgs
struct ARPointCloudChangedEventArgs_t7DE4CA4D30D369496221061F89CC4BF84E42CC1B_marshaled_com
{
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CaddedU3Ek__BackingField_0;
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tB9CD639EB4FE5EA0A8B417168BB9BD2D29AEE271* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARPointCloudUpdatedEventArgs
struct ARPointCloudUpdatedEventArgs_t9AC3E8FAC2452088DE276694AFE257D823EB79B4 
{
	union
	{
		struct
		{
		};
		uint8_t ARPointCloudUpdatedEventArgs_t9AC3E8FAC2452088DE276694AFE257D823EB79B4__padding[1];
	};
};

// UnityEngine.XR.ARFoundation.ARRaycastUpdatedEventArgs
struct ARRaycastUpdatedEventArgs_t4F200C75C97D91C3B96D3E6018CD31B9E9E19D6B 
{
	// UnityEngine.XR.ARFoundation.ARRaycast UnityEngine.XR.ARFoundation.ARRaycastUpdatedEventArgs::<raycast>k__BackingField
	ARRaycast_t141143E16F40B1580060317DA867423FF2624E76* ___U3CraycastU3Ek__BackingField_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARRaycastUpdatedEventArgs
struct ARRaycastUpdatedEventArgs_t4F200C75C97D91C3B96D3E6018CD31B9E9E19D6B_marshaled_pinvoke
{
	ARRaycast_t141143E16F40B1580060317DA867423FF2624E76* ___U3CraycastU3Ek__BackingField_0;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARRaycastUpdatedEventArgs
struct ARRaycastUpdatedEventArgs_t4F200C75C97D91C3B96D3E6018CD31B9E9E19D6B_marshaled_com
{
	ARRaycast_t141143E16F40B1580060317DA867423FF2624E76* ___U3CraycastU3Ek__BackingField_0;
};

// UnityEngine.XR.ARFoundation.ARReferencePointsChangedEventArgs
struct ARReferencePointsChangedEventArgs_t25F5471C71BDC45AB77834E2F331931EE37F7B62 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARReferencePoint> UnityEngine.XR.ARFoundation.ARReferencePointsChangedEventArgs::<added>k__BackingField
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARReferencePoint> UnityEngine.XR.ARFoundation.ARReferencePointsChangedEventArgs::<updated>k__BackingField
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARReferencePoint> UnityEngine.XR.ARFoundation.ARReferencePointsChangedEventArgs::<removed>k__BackingField
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARReferencePointsChangedEventArgs
struct ARReferencePointsChangedEventArgs_t25F5471C71BDC45AB77834E2F331931EE37F7B62_marshaled_pinvoke
{
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CaddedU3Ek__BackingField_0;
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARReferencePointsChangedEventArgs
struct ARReferencePointsChangedEventArgs_t25F5471C71BDC45AB77834E2F331931EE37F7B62_marshaled_com
{
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CaddedU3Ek__BackingField_0;
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CupdatedU3Ek__BackingField_1;
	List_1_t2FD8903BBE837973AFCE154B4045672F6F238D2A* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARSessionStateChangedEventArgs
struct ARSessionStateChangedEventArgs_tC31BD123D6B4F6168FB246762E79AB33962AE822 
{
	// UnityEngine.XR.ARFoundation.ARSessionState UnityEngine.XR.ARFoundation.ARSessionStateChangedEventArgs::<state>k__BackingField
	int32_t ___U3CstateU3Ek__BackingField_0;
};

// UnityEngine.XR.ARFoundation.ARTrackablesParentTransformChangedEventArgs
struct ARTrackablesParentTransformChangedEventArgs_tEF673BCB9382697300AE683ED29F0BF96E4A9C8A 
{
	// UnityEngine.XR.ARFoundation.ARSessionOrigin UnityEngine.XR.ARFoundation.ARTrackablesParentTransformChangedEventArgs::<sessionOrigin>k__BackingField
	ARSessionOrigin_tE7B28A1A19500BCC02711397A19E330425830BC3* ___U3CsessionOriginU3Ek__BackingField_0;
	// UnityEngine.Transform UnityEngine.XR.ARFoundation.ARTrackablesParentTransformChangedEventArgs::<trackablesParent>k__BackingField
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___U3CtrackablesParentU3Ek__BackingField_1;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARTrackablesParentTransformChangedEventArgs
struct ARTrackablesParentTransformChangedEventArgs_tEF673BCB9382697300AE683ED29F0BF96E4A9C8A_marshaled_pinvoke
{
	ARSessionOrigin_tE7B28A1A19500BCC02711397A19E330425830BC3* ___U3CsessionOriginU3Ek__BackingField_0;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___U3CtrackablesParentU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARTrackablesParentTransformChangedEventArgs
struct ARTrackablesParentTransformChangedEventArgs_tEF673BCB9382697300AE683ED29F0BF96E4A9C8A_marshaled_com
{
	ARSessionOrigin_tE7B28A1A19500BCC02711397A19E330425830BC3* ___U3CsessionOriginU3Ek__BackingField_0;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___U3CtrackablesParentU3Ek__BackingField_1;
};

// UnityEngine.XR.ARFoundation.ARTrackedImagesChangedEventArgs
struct ARTrackedImagesChangedEventArgs_tD7718E40EE25D22E9143DA4F556C44980E18BE2F 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedImage> UnityEngine.XR.ARFoundation.ARTrackedImagesChangedEventArgs::<added>k__BackingField
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedImage> UnityEngine.XR.ARFoundation.ARTrackedImagesChangedEventArgs::<updated>k__BackingField
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedImage> UnityEngine.XR.ARFoundation.ARTrackedImagesChangedEventArgs::<removed>k__BackingField
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARTrackedImagesChangedEventArgs
struct ARTrackedImagesChangedEventArgs_tD7718E40EE25D22E9143DA4F556C44980E18BE2F_marshaled_pinvoke
{
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CaddedU3Ek__BackingField_0;
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARTrackedImagesChangedEventArgs
struct ARTrackedImagesChangedEventArgs_tD7718E40EE25D22E9143DA4F556C44980E18BE2F_marshaled_com
{
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CaddedU3Ek__BackingField_0;
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tFA730335FF46512E4245B2F46892CA318B394FAE* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.XR.ARFoundation.ARTrackedObjectsChangedEventArgs
struct ARTrackedObjectsChangedEventArgs_t378A63B91AD22EA4BA9C68805C72DDA4B7C01509 
{
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedObject> UnityEngine.XR.ARFoundation.ARTrackedObjectsChangedEventArgs::<added>k__BackingField
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CaddedU3Ek__BackingField_0;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedObject> UnityEngine.XR.ARFoundation.ARTrackedObjectsChangedEventArgs::<updated>k__BackingField
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CupdatedU3Ek__BackingField_1;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARFoundation.ARTrackedObject> UnityEngine.XR.ARFoundation.ARTrackedObjectsChangedEventArgs::<removed>k__BackingField
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARTrackedObjectsChangedEventArgs
struct ARTrackedObjectsChangedEventArgs_t378A63B91AD22EA4BA9C68805C72DDA4B7C01509_marshaled_pinvoke
{
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CaddedU3Ek__BackingField_0;
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CremovedU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARTrackedObjectsChangedEventArgs
struct ARTrackedObjectsChangedEventArgs_t378A63B91AD22EA4BA9C68805C72DDA4B7C01509_marshaled_com
{
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CaddedU3Ek__BackingField_0;
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CupdatedU3Ek__BackingField_1;
	List_1_tF1201F2F725A8AE529D436F38A4771FB6790F3C6* ___U3CremovedU3Ek__BackingField_2;
};

// UnityEngine.Rendering.BatchPackedCullingViewID
struct BatchPackedCullingViewID_t1E7EE8631C02555CAA181FA566CDC604B9FEFEBB 
{
	// System.UInt64 UnityEngine.Rendering.BatchPackedCullingViewID::handle
	uint64_t ___handle_0;
};

// UnityEngine.Color
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;
};

// System.ConsoleKeyInfo
struct ConsoleKeyInfo_t84640C60F53D0F6946B147ADAAF0366BBF1DE900 
{
	// System.Char System.ConsoleKeyInfo::_keyChar
	Il2CppChar ____keyChar_0;
	// System.ConsoleKey System.ConsoleKeyInfo::_key
	int32_t ____key_1;
	// System.ConsoleModifiers System.ConsoleKeyInfo::_mods
	int32_t ____mods_2;
};
// Native definition for P/Invoke marshalling of System.ConsoleKeyInfo
struct ConsoleKeyInfo_t84640C60F53D0F6946B147ADAAF0366BBF1DE900_marshaled_pinvoke
{
	uint8_t ____keyChar_0;
	int32_t ____key_1;
	int32_t ____mods_2;
};
// Native definition for COM marshalling of System.ConsoleKeyInfo
struct ConsoleKeyInfo_t84640C60F53D0F6946B147ADAAF0366BBF1DE900_marshaled_com
{
	uint8_t ____keyChar_0;
	int32_t ____key_1;
	int32_t ____mods_2;
};

// UnityEngine.CullingGroupEvent
struct CullingGroupEvent_tC79BA328A8280C29F6002F591614081A0E87D110 
{
	// System.Int32 UnityEngine.CullingGroupEvent::m_Index
	int32_t ___m_Index_0;
	// System.Byte UnityEngine.CullingGroupEvent::m_PrevState
	uint8_t ___m_PrevState_1;
	// System.Byte UnityEngine.CullingGroupEvent::m_ThisState
	uint8_t ___m_ThisState_2;
};

// System.Reflection.CustomAttributeTypedArgument
struct CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F 
{
	// System.Type System.Reflection.CustomAttributeTypedArgument::<ArgumentType>k__BackingField
	Type_t* ___U3CArgumentTypeU3Ek__BackingField_0;
	// System.Object System.Reflection.CustomAttributeTypedArgument::<Value>k__BackingField
	RuntimeObject* ___U3CValueU3Ek__BackingField_1;
};
// Native definition for P/Invoke marshalling of System.Reflection.CustomAttributeTypedArgument
struct CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F_marshaled_pinvoke
{
	Type_t* ___U3CArgumentTypeU3Ek__BackingField_0;
	Il2CppIUnknown* ___U3CValueU3Ek__BackingField_1;
};
// Native definition for COM marshalling of System.Reflection.CustomAttributeTypedArgument
struct CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F_marshaled_com
{
	Type_t* ___U3CArgumentTypeU3Ek__BackingField_0;
	Il2CppIUnknown* ___U3CValueU3Ek__BackingField_1;
};

// System.DateTime
struct DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D 
{
	// System.UInt64 System.DateTime::_dateData
	uint64_t ____dateData_46;
};

struct DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D_StaticFields
{
	// System.Int32[] System.DateTime::s_daysToMonth365
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___s_daysToMonth365_30;
	// System.Int32[] System.DateTime::s_daysToMonth366
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___s_daysToMonth366_31;
	// System.DateTime System.DateTime::MinValue
	DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D ___MinValue_32;
	// System.DateTime System.DateTime::MaxValue
	DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D ___MaxValue_33;
	// System.DateTime System.DateTime::UnixEpoch
	DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D ___UnixEpoch_34;
};

// System.Decimal
struct Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F 
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Int32 System.Decimal::flags
			int32_t ___flags_5;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___flags_5_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___hi_6_OffsetPadding[4];
			// System.Int32 System.Decimal::hi
			int32_t ___hi_6;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___hi_6_OffsetPadding_forAlignmentOnly[4];
			int32_t ___hi_6_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___lo_7_OffsetPadding[8];
			// System.Int32 System.Decimal::lo
			int32_t ___lo_7;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___lo_7_OffsetPadding_forAlignmentOnly[8];
			int32_t ___lo_7_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___mid_8_OffsetPadding[12];
			// System.Int32 System.Decimal::mid
			int32_t ___mid_8;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___mid_8_OffsetPadding_forAlignmentOnly[12];
			int32_t ___mid_8_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___ulomidLE_9_OffsetPadding[8];
			// System.UInt64 System.Decimal::ulomidLE
			uint64_t ___ulomidLE_9;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___ulomidLE_9_OffsetPadding_forAlignmentOnly[8];
			uint64_t ___ulomidLE_9_forAlignmentOnly;
		};
	};
};

struct Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F_StaticFields
{
	// System.Decimal System.Decimal::Zero
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F ___Zero_0;
	// System.Decimal System.Decimal::One
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F ___One_1;
	// System.Decimal System.Decimal::MinusOne
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F ___MinusOne_2;
	// System.Decimal System.Decimal::MaxValue
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F ___MaxValue_3;
	// System.Decimal System.Decimal::MinValue
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F ___MinValue_4;
};

// System.Collections.DictionaryEntry
struct DictionaryEntry_t171080F37B311C25AA9E75888F9C9D703FA721BB 
{
	// System.Object System.Collections.DictionaryEntry::_key
	RuntimeObject* ____key_0;
	// System.Object System.Collections.DictionaryEntry::_value
	RuntimeObject* ____value_1;
};
// Native definition for P/Invoke marshalling of System.Collections.DictionaryEntry
struct DictionaryEntry_t171080F37B311C25AA9E75888F9C9D703FA721BB_marshaled_pinvoke
{
	Il2CppIUnknown* ____key_0;
	Il2CppIUnknown* ____value_1;
};
// Native definition for COM marshalling of System.Collections.DictionaryEntry
struct DictionaryEntry_t171080F37B311C25AA9E75888F9C9D703FA721BB_marshaled_com
{
	Il2CppIUnknown* ____key_0;
	Il2CppIUnknown* ____value_1;
};

// System.Guid
struct Guid_t 
{
	// System.Int32 System.Guid::_a
	int32_t ____a_1;
	// System.Int16 System.Guid::_b
	int16_t ____b_2;
	// System.Int16 System.Guid::_c
	int16_t ____c_3;
	// System.Byte System.Guid::_d
	uint8_t ____d_4;
	// System.Byte System.Guid::_e
	uint8_t ____e_5;
	// System.Byte System.Guid::_f
	uint8_t ____f_6;
	// System.Byte System.Guid::_g
	uint8_t ____g_7;
	// System.Byte System.Guid::_h
	uint8_t ____h_8;
	// System.Byte System.Guid::_i
	uint8_t ____i_9;
	// System.Byte System.Guid::_j
	uint8_t ____j_10;
	// System.Byte System.Guid::_k
	uint8_t ____k_11;
};

struct Guid_t_StaticFields
{
	// System.Guid System.Guid::Empty
	Guid_t ___Empty_0;
};

// UnityEngine.XR.InputDevice
struct InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD 
{
	// System.UInt64 UnityEngine.XR.InputDevice::m_DeviceId
	uint64_t ___m_DeviceId_1;
	// System.Boolean UnityEngine.XR.InputDevice::m_Initialized
	bool ___m_Initialized_2;
};

struct InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD_StaticFields
{
	// System.Collections.Generic.List`1<UnityEngine.XR.XRInputSubsystem> UnityEngine.XR.InputDevice::s_InputSubsystemCache
	List_1_t90832B88D7207769654164CC28440CF594CC397D* ___s_InputSubsystemCache_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.InputDevice
struct InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD_marshaled_pinvoke
{
	uint64_t ___m_DeviceId_1;
	int32_t ___m_Initialized_2;
};
// Native definition for COM marshalling of UnityEngine.XR.InputDevice
struct InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD_marshaled_com
{
	uint64_t ___m_DeviceId_1;
	int32_t ___m_Initialized_2;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

struct IntPtr_t_StaticFields
{
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;
};

// UnityEngine.Matrix4x4
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 
{
	// System.Single UnityEngine.Matrix4x4::m00
	float ___m00_0;
	// System.Single UnityEngine.Matrix4x4::m10
	float ___m10_1;
	// System.Single UnityEngine.Matrix4x4::m20
	float ___m20_2;
	// System.Single UnityEngine.Matrix4x4::m30
	float ___m30_3;
	// System.Single UnityEngine.Matrix4x4::m01
	float ___m01_4;
	// System.Single UnityEngine.Matrix4x4::m11
	float ___m11_5;
	// System.Single UnityEngine.Matrix4x4::m21
	float ___m21_6;
	// System.Single UnityEngine.Matrix4x4::m31
	float ___m31_7;
	// System.Single UnityEngine.Matrix4x4::m02
	float ___m02_8;
	// System.Single UnityEngine.Matrix4x4::m12
	float ___m12_9;
	// System.Single UnityEngine.Matrix4x4::m22
	float ___m22_10;
	// System.Single UnityEngine.Matrix4x4::m32
	float ___m32_11;
	// System.Single UnityEngine.Matrix4x4::m03
	float ___m03_12;
	// System.Single UnityEngine.Matrix4x4::m13
	float ___m13_13;
	// System.Single UnityEngine.Matrix4x4::m23
	float ___m23_14;
	// System.Single UnityEngine.Matrix4x4::m33
	float ___m33_15;
};

struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6_StaticFields
{
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::zeroMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___zeroMatrix_16;
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::identityMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___identityMatrix_17;
};

// UnityEngine.XR.MeshId
struct MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC 
{
	// System.UInt64 UnityEngine.XR.MeshId::m_SubId1
	uint64_t ___m_SubId1_1;
	// System.UInt64 UnityEngine.XR.MeshId::m_SubId2
	uint64_t ___m_SubId2_2;
};

struct MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC_StaticFields
{
	// UnityEngine.XR.MeshId UnityEngine.XR.MeshId::s_InvalidId
	MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC ___s_InvalidId_0;
};

// UnityEngine.PhysicsScene
struct PhysicsScene_t55222DD37072E8560EE054A07C0E3FE391D9D9DE 
{
	// System.Int32 UnityEngine.PhysicsScene::m_Handle
	int32_t ___m_Handle_0;
};

// UnityEngine.Quaternion
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 
{
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;
};

struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_StaticFields
{
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___identityQuaternion_4;
};

// UnityEngine.RectInt
struct RectInt_t1744D10E1063135DA9D574F95205B98DAC600CB8 
{
	// System.Int32 UnityEngine.RectInt::m_XMin
	int32_t ___m_XMin_0;
	// System.Int32 UnityEngine.RectInt::m_YMin
	int32_t ___m_YMin_1;
	// System.Int32 UnityEngine.RectInt::m_Width
	int32_t ___m_Width_2;
	// System.Int32 UnityEngine.RectInt::m_Height
	int32_t ___m_Height_3;
};

// System.Resources.ResourceLocator
struct ResourceLocator_t84F68A0DD2AA185761938E49BBE9B2C46A47E122 
{
	// System.Object System.Resources.ResourceLocator::_value
	RuntimeObject* ____value_0;
	// System.Int32 System.Resources.ResourceLocator::_dataPos
	int32_t ____dataPos_1;
};
// Native definition for P/Invoke marshalling of System.Resources.ResourceLocator
struct ResourceLocator_t84F68A0DD2AA185761938E49BBE9B2C46A47E122_marshaled_pinvoke
{
	Il2CppIUnknown* ____value_0;
	int32_t ____dataPos_1;
};
// Native definition for COM marshalling of System.Resources.ResourceLocator
struct ResourceLocator_t84F68A0DD2AA185761938E49BBE9B2C46A47E122_marshaled_com
{
	Il2CppIUnknown* ____value_0;
	int32_t ____dataPos_1;
};

// UnityEngine.SceneManagement.Scene
struct Scene_tA1DC762B79745EB5140F054C884855B922318356 
{
	// System.Int32 UnityEngine.SceneManagement.Scene::m_Handle
	int32_t ___m_Handle_0;
};

// UnityEngine.XR.ARSubsystems.SerializableGuid
struct SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 
{
	// System.UInt64 UnityEngine.XR.ARSubsystems.SerializableGuid::m_GuidLow
	uint64_t ___m_GuidLow_1;
	// System.UInt64 UnityEngine.XR.ARSubsystems.SerializableGuid::m_GuidHigh
	uint64_t ___m_GuidHigh_2;
};

struct SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378_StaticFields
{
	// UnityEngine.XR.ARSubsystems.SerializableGuid UnityEngine.XR.ARSubsystems.SerializableGuid::k_Empty
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___k_Empty_0;
};

// UnityEngine.Rendering.ShaderTagId
struct ShaderTagId_t453E2085B5EE9448FF75E550CAB111EFF690ECB0 
{
	// System.Int32 UnityEngine.Rendering.ShaderTagId::m_Id
	int32_t ___m_Id_0;
};

// UnityEngine.Rendering.SphericalHarmonicsL2
struct SphericalHarmonicsL2_tCBFB646455D2069E738976E5B745C6DF023B6BA2 
{
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr0
	float ___shr0_0;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr1
	float ___shr1_1;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr2
	float ___shr2_2;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr3
	float ___shr3_3;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr4
	float ___shr4_4;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr5
	float ___shr5_5;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr6
	float ___shr6_6;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr7
	float ___shr7_7;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shr8
	float ___shr8_8;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg0
	float ___shg0_9;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg1
	float ___shg1_10;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg2
	float ___shg2_11;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg3
	float ___shg3_12;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg4
	float ___shg4_13;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg5
	float ___shg5_14;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg6
	float ___shg6_15;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg7
	float ___shg7_16;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shg8
	float ___shg8_17;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb0
	float ___shb0_18;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb1
	float ___shb1_19;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb2
	float ___shb2_20;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb3
	float ___shb3_21;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb4
	float ___shb4_22;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb5
	float ___shb5_23;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb6
	float ___shb6_24;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb7
	float ___shb7_25;
	// System.Single UnityEngine.Rendering.SphericalHarmonicsL2::shb8
	float ___shb8_26;
};

// System.Runtime.Serialization.StreamingContext
struct StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 
{
	// System.Object System.Runtime.Serialization.StreamingContext::m_additionalContext
	RuntimeObject* ___m_additionalContext_0;
	// System.Runtime.Serialization.StreamingContextStates System.Runtime.Serialization.StreamingContext::m_state
	int32_t ___m_state_1;
};
// Native definition for P/Invoke marshalling of System.Runtime.Serialization.StreamingContext
struct StreamingContext_t56760522A751890146EE45F82F866B55B7E33677_marshaled_pinvoke
{
	Il2CppIUnknown* ___m_additionalContext_0;
	int32_t ___m_state_1;
};
// Native definition for COM marshalling of System.Runtime.Serialization.StreamingContext
struct StreamingContext_t56760522A751890146EE45F82F866B55B7E33677_marshaled_com
{
	Il2CppIUnknown* ___m_additionalContext_0;
	int32_t ___m_state_1;
};

// System.TimeSpan
struct TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A 
{
	// System.Int64 System.TimeSpan::_ticks
	int64_t ____ticks_22;
};

struct TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A_StaticFields
{
	// System.TimeSpan System.TimeSpan::Zero
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A ___Zero_19;
	// System.TimeSpan System.TimeSpan::MaxValue
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A ___MaxValue_20;
	// System.TimeSpan System.TimeSpan::MinValue
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A ___MinValue_21;
};

// UnityEngine.XR.ARSubsystems.TrackableId
struct TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 
{
	// System.UInt64 UnityEngine.XR.ARSubsystems.TrackableId::m_SubId1
	uint64_t ___m_SubId1_2;
	// System.UInt64 UnityEngine.XR.ARSubsystems.TrackableId::m_SubId2
	uint64_t ___m_SubId2_3;
};

struct TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7_StaticFields
{
	// System.Text.RegularExpressions.Regex UnityEngine.XR.ARSubsystems.TrackableId::s_TrackableIdRegex
	Regex_tE773142C2BE45C5D362B0F815AFF831707A51772* ___s_TrackableIdRegex_0;
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.TrackableId::s_InvalidId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___s_InvalidId_1;
};

// UnityEngine.Vector2
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;
};

struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___negativeInfinityVector_9;
};

// UnityEngine.Vector2Int
struct Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A 
{
	// System.Int32 UnityEngine.Vector2Int::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.Vector2Int::m_Y
	int32_t ___m_Y_1;
};

struct Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A_StaticFields
{
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Zero
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Zero_2;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_One
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_One_3;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Up
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Up_4;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Down
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Down_5;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Left
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Left_6;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Right
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Right_7;
};

// UnityEngine.Vector3
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;
};

struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields
{
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___negativeInfinityVector_14;
};

// System.Threading.Tasks.VoidTaskResult
struct VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC 
{
	union
	{
		struct
		{
		};
		uint8_t VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC__padding[1];
	};
};

// UnityEngine.XR.ARSubsystems.XRCameraParams
struct XRCameraParams_t2EBCCDA7FA502A7BDA940461C44C7817E5B44B40 
{
	// System.Single UnityEngine.XR.ARSubsystems.XRCameraParams::m_ZNear
	float ___m_ZNear_0;
	// System.Single UnityEngine.XR.ARSubsystems.XRCameraParams::m_ZFar
	float ___m_ZFar_1;
	// System.Single UnityEngine.XR.ARSubsystems.XRCameraParams::m_ScreenWidth
	float ___m_ScreenWidth_2;
	// System.Single UnityEngine.XR.ARSubsystems.XRCameraParams::m_ScreenHeight
	float ___m_ScreenHeight_3;
	// UnityEngine.ScreenOrientation UnityEngine.XR.ARSubsystems.XRCameraParams::m_ScreenOrientation
	int32_t ___m_ScreenOrientation_4;
};

// UnityEngine.XR.ARSubsystems.XRReferenceObject
struct XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 
{
	// System.UInt64 UnityEngine.XR.ARSubsystems.XRReferenceObject::m_GuidLow
	uint64_t ___m_GuidLow_0;
	// System.UInt64 UnityEngine.XR.ARSubsystems.XRReferenceObject::m_GuidHigh
	uint64_t ___m_GuidHigh_1;
	// System.String UnityEngine.XR.ARSubsystems.XRReferenceObject::m_Name
	String_t* ___m_Name_2;
	// System.Collections.Generic.List`1<UnityEngine.XR.ARSubsystems.XRReferenceObjectEntry> UnityEngine.XR.ARSubsystems.XRReferenceObject::m_Entries
	List_1_tC0E7595725AFEF62394C64B77712190FBAC6C2C5* ___m_Entries_3;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARSubsystems.XRReferenceObject
struct XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14_marshaled_pinvoke
{
	uint64_t ___m_GuidLow_0;
	uint64_t ___m_GuidHigh_1;
	char* ___m_Name_2;
	List_1_tC0E7595725AFEF62394C64B77712190FBAC6C2C5* ___m_Entries_3;
};
// Native definition for COM marshalling of UnityEngine.XR.ARSubsystems.XRReferenceObject
struct XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14_marshaled_com
{
	uint64_t ___m_GuidLow_0;
	uint64_t ___m_GuidHigh_1;
	Il2CppChar* ___m_Name_2;
	List_1_tC0E7595725AFEF62394C64B77712190FBAC6C2C5* ___m_Entries_3;
};

// UnityEngine.BeforeRenderHelper/OrderBlock
struct OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 
{
	// System.Int32 UnityEngine.BeforeRenderHelper/OrderBlock::order
	int32_t ___order_0;
	// UnityEngine.Events.UnityAction UnityEngine.BeforeRenderHelper/OrderBlock::callback
	UnityAction_t11A1F3B953B365C072A5DCC32677EE1796A962A7* ___callback_1;
};
// Native definition for P/Invoke marshalling of UnityEngine.BeforeRenderHelper/OrderBlock
struct OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837_marshaled_pinvoke
{
	int32_t ___order_0;
	Il2CppMethodPointer ___callback_1;
};
// Native definition for COM marshalling of UnityEngine.BeforeRenderHelper/OrderBlock
struct OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837_marshaled_com
{
	int32_t ___order_0;
	Il2CppMethodPointer ___callback_1;
};

// UnityEngine.Camera/RenderRequest
struct RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A 
{
	// UnityEngine.Camera/RenderRequestMode UnityEngine.Camera/RenderRequest::m_CameraRenderMode
	int32_t ___m_CameraRenderMode_0;
	// UnityEngine.RenderTexture UnityEngine.Camera/RenderRequest::m_ResultRT
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___m_ResultRT_1;
	// UnityEngine.Camera/RenderRequestOutputSpace UnityEngine.Camera/RenderRequest::m_OutputSpace
	int32_t ___m_OutputSpace_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.Camera/RenderRequest
struct RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A_marshaled_pinvoke
{
	int32_t ___m_CameraRenderMode_0;
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___m_ResultRT_1;
	int32_t ___m_OutputSpace_2;
};
// Native definition for COM marshalling of UnityEngine.Camera/RenderRequest
struct RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A_marshaled_com
{
	int32_t ___m_CameraRenderMode_0;
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___m_ResultRT_1;
	int32_t ___m_OutputSpace_2;
};

// System.Text.RegularExpressions.Regex/CachedCodeEntryKey
struct CachedCodeEntryKey_t8A54BDD6E52145D17DB1A2EB0CE0B4D4CB112F31 
{
	// System.Text.RegularExpressions.RegexOptions System.Text.RegularExpressions.Regex/CachedCodeEntryKey::_options
	int32_t ____options_0;
	// System.String System.Text.RegularExpressions.Regex/CachedCodeEntryKey::_cultureKey
	String_t* ____cultureKey_1;
	// System.String System.Text.RegularExpressions.Regex/CachedCodeEntryKey::_pattern
	String_t* ____pattern_2;
};
// Native definition for P/Invoke marshalling of System.Text.RegularExpressions.Regex/CachedCodeEntryKey
struct CachedCodeEntryKey_t8A54BDD6E52145D17DB1A2EB0CE0B4D4CB112F31_marshaled_pinvoke
{
	int32_t ____options_0;
	char* ____cultureKey_1;
	char* ____pattern_2;
};
// Native definition for COM marshalling of System.Text.RegularExpressions.Regex/CachedCodeEntryKey
struct CachedCodeEntryKey_t8A54BDD6E52145D17DB1A2EB0CE0B4D4CB112F31_marshaled_com
{
	int32_t ____options_0;
	Il2CppChar* ____cultureKey_1;
	Il2CppChar* ____pattern_2;
};

// System.Text.RegularExpressions.RegexCharClass/SingleRange
struct SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC 
{
	// System.Char System.Text.RegularExpressions.RegexCharClass/SingleRange::First
	Il2CppChar ___First_0;
	// System.Char System.Text.RegularExpressions.RegexCharClass/SingleRange::Last
	Il2CppChar ___Last_1;
};
// Native definition for P/Invoke marshalling of System.Text.RegularExpressions.RegexCharClass/SingleRange
struct SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC_marshaled_pinvoke
{
	uint8_t ___First_0;
	uint8_t ___Last_1;
};
// Native definition for COM marshalling of System.Text.RegularExpressions.RegexCharClass/SingleRange
struct SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC_marshaled_com
{
	uint8_t ___First_0;
	uint8_t ___Last_1;
};

// UnityEngine.SpatialTracking.TrackedPoseDriverDataDescription/PoseData
struct PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A 
{
	// System.Collections.Generic.List`1<System.String> UnityEngine.SpatialTracking.TrackedPoseDriverDataDescription/PoseData::PoseNames
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___PoseNames_0;
	// System.Collections.Generic.List`1<UnityEngine.SpatialTracking.TrackedPoseDriver/TrackedPose> UnityEngine.SpatialTracking.TrackedPoseDriverDataDescription/PoseData::Poses
	List_1_t8A06DB5554CD76CE072807DE6EF4198109D84E53* ___Poses_1;
};
// Native definition for P/Invoke marshalling of UnityEngine.SpatialTracking.TrackedPoseDriverDataDescription/PoseData
struct PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A_marshaled_pinvoke
{
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___PoseNames_0;
	List_1_t8A06DB5554CD76CE072807DE6EF4198109D84E53* ___Poses_1;
};
// Native definition for COM marshalling of UnityEngine.SpatialTracking.TrackedPoseDriverDataDescription/PoseData
struct PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A_marshaled_com
{
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___PoseNames_0;
	List_1_t8A06DB5554CD76CE072807DE6EF4198109D84E53* ___Poses_1;
};

// UnityEngine.UnitySynchronizationContext/WorkRequest
struct WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 
{
	// System.Threading.SendOrPostCallback UnityEngine.UnitySynchronizationContext/WorkRequest::m_DelagateCallback
	SendOrPostCallback_t5C292A12062F24027A98492F52ECFE9802AA6F0E* ___m_DelagateCallback_0;
	// System.Object UnityEngine.UnitySynchronizationContext/WorkRequest::m_DelagateState
	RuntimeObject* ___m_DelagateState_1;
	// System.Threading.ManualResetEvent UnityEngine.UnitySynchronizationContext/WorkRequest::m_WaitHandle
	ManualResetEvent_t63959486AA41A113A4353D0BF4A68E77EBA0A158* ___m_WaitHandle_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.UnitySynchronizationContext/WorkRequest
struct WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44_marshaled_pinvoke
{
	Il2CppMethodPointer ___m_DelagateCallback_0;
	Il2CppIUnknown* ___m_DelagateState_1;
	ManualResetEvent_t63959486AA41A113A4353D0BF4A68E77EBA0A158* ___m_WaitHandle_2;
};
// Native definition for COM marshalling of UnityEngine.UnitySynchronizationContext/WorkRequest
struct WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44_marshaled_com
{
	Il2CppMethodPointer ___m_DelagateCallback_0;
	Il2CppIUnknown* ___m_DelagateState_1;
	ManualResetEvent_t63959486AA41A113A4353D0BF4A68E77EBA0A158* ___m_WaitHandle_2;
};

// System.ByReference`1<System.Byte>
struct ByReference_1_t9C85BCCAAF8C525B6C06B07E922D8D217BE8D6FC 
{
	// System.IntPtr System.ByReference`1::_value
	intptr_t ____value_0;
};

// System.ByReference`1<System.Char>
struct ByReference_1_t7BA5A6CA164F770BC688F21C5978D368716465F5 
{
	// System.IntPtr System.ByReference`1::_value
	intptr_t ____value_0;
};

// System.Nullable`1<UnityEngine.Color>
struct Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___value_1;
};

// System.Nullable`1<UnityEngine.Matrix4x4>
struct Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___value_1;
};

// System.Nullable`1<UnityEngine.Rendering.SphericalHarmonicsL2>
struct Nullable_1_t4C9CB95ACA9906A61C759884064F60858BF7E798 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	SphericalHarmonicsL2_tCBFB646455D2069E738976E5B745C6DF023B6BA2 ___value_1;
};

// System.Nullable`1<UnityEngine.Vector3>
struct Nullable_1_t9C51B084784B716FFF4ED4575C63CFD8A71A86FE 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___value_1;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.BoundedPlane>
struct TrackableChanges_1_tFC79B2E1FF9EFB1D5754F6995583D33A519F300F 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t36CA775B66FDBC3A63AF9ABB6E32E8F6B41F824C ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t36CA775B66FDBC3A63AF9ABB6E32E8F6B41F824C ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRAnchor>
struct TrackableChanges_1_t6971CD7F709E7353F4365FE06A109B21A0F0C931 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_tAE2F2F17B6A4F98F44324897A00F6A9D2151DC3A ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_tAE2F2F17B6A4F98F44324897A00F6A9D2151DC3A ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XREnvironmentProbe>
struct TrackableChanges_1_t03BF8B384A61E7421A4748384189C50C3A2C323F 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t27110FD746D2F878E09169A93400CE1027082DA2 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t27110FD746D2F878E09169A93400CE1027082DA2 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRFace>
struct TrackableChanges_1_t244050823CF4D8F3C9DFAE4AB0CEFA639C719119 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t944085523DA105D6BBD308E9159C874CE60B3009 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t944085523DA105D6BBD308E9159C874CE60B3009 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRHumanBody>
struct TrackableChanges_1_tAB0D56187755251BCF253FBC179ABFC1B18E00C6 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t5B6781386C81B6DAD0A46599F36186F644DC17D0 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t5B6781386C81B6DAD0A46599F36186F644DC17D0 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRParticipant>
struct TrackableChanges_1_t2CDAB668CF6C2AB6D755F9C2911626A1C9140179 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t79743910830B59034ED2B060D4E1D0EC70226E18 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t79743910830B59034ED2B060D4E1D0EC70226E18 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRPointCloud>
struct TrackableChanges_1_t33787F6E969DAC65E8C2FD57FE6AAC9119CFDB89 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t50096787A7C7D874EC2A53B03F61419BE240D9C0 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t50096787A7C7D874EC2A53B03F61419BE240D9C0 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRRaycast>
struct TrackableChanges_1_t097463074AB33F65828FED3152F6A605C0B114A5 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t43267D13364B938F522273E473A86557B971CD63 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t43267D13364B938F522273E473A86557B971CD63 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRReferencePoint>
struct TrackableChanges_1_t570BA80B84560BB489FE51A45629812BC8E0B02F 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t25DC732E6C086A8D9E0F2322692DDD67260AF33B ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t25DC732E6C086A8D9E0F2322692DDD67260AF33B ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRTrackedImage>
struct TrackableChanges_1_t5289D1DB76FBCB9C1A7B387927387F4299599C1E 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_tC503E651BA1B71B961BBC7485E923DD431EFCC66 ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_tC503E651BA1B71B961BBC7485E923DD431EFCC66 ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// UnityEngine.XR.ARSubsystems.TrackableChanges`1<UnityEngine.XR.ARSubsystems.XRTrackedObject>
struct TrackableChanges_1_tBC4635C00390DED792828CD9C45501D0F38AFEE6 
{
	// System.Boolean UnityEngine.XR.ARSubsystems.TrackableChanges`1::<isCreated>k__BackingField
	bool ___U3CisCreatedU3Ek__BackingField_0;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Added
	NativeArray_1_t0F4B76D476AFCD1C3D325B2AF615317AF55BE50B ___m_Added_1;
	// Unity.Collections.NativeArray`1<T> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Updated
	NativeArray_1_t0F4B76D476AFCD1C3D325B2AF615317AF55BE50B ___m_Updated_2;
	// Unity.Collections.NativeArray`1<UnityEngine.XR.ARSubsystems.TrackableId> UnityEngine.XR.ARSubsystems.TrackableChanges`1::m_Removed
	NativeArray_1_t7A26520FDE477098D7B2CC8D14E778889D50A15E ___m_Removed_3;
};

// System.ValueTuple`5<System.IntPtr,System.Int32,System.IntPtr,System.Int32,System.Boolean>
struct ValueTuple_5_t558B9F95CA55DE5694FC58A3BEAE441BF728FB57 
{
	// T1 System.ValueTuple`5::Item1
	intptr_t ___Item1_0;
	// T2 System.ValueTuple`5::Item2
	int32_t ___Item2_1;
	// T3 System.ValueTuple`5::Item3
	intptr_t ___Item3_2;
	// T4 System.ValueTuple`5::Item4
	int32_t ___Item4_3;
	// T5 System.ValueTuple`5::Item5
	bool ___Item5_4;
};

// UnityEngine.XR.ARCore.ArCameraConfigFilter
struct ArCameraConfigFilter_tF665AEAE3CDEB76E6485508096A093A9E0E0B607 
{
	// System.IntPtr UnityEngine.XR.ARCore.ArCameraConfigFilter::m_Self
	intptr_t ___m_Self_0;
};

// UnityEngine.XR.ARCore.ArConfig
struct ArConfig_tC991F7E3046E638B111BDBE5A2B25C4F363C4F1C 
{
	// System.IntPtr UnityEngine.XR.ARCore.ArConfig::m_Self
	intptr_t ___m_Self_0;
};

// UnityEngine.XR.ARCore.ArSession
struct ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF 
{
	// System.IntPtr UnityEngine.XR.ARCore.ArSession::m_Self
	intptr_t ___m_Self_0;
};

// UnityEngine.Rendering.BatchCullingOutput
struct BatchCullingOutput_tF997DE602CE8F5E44654FD157113EF455DBE785F 
{
	// Unity.Collections.NativeArray`1<UnityEngine.Rendering.BatchCullingOutputDrawCommands> UnityEngine.Rendering.BatchCullingOutput::drawCommands
	NativeArray_1_tBEE3484B4ABC271CFAB65039F1439061D5DF806A ___drawCommands_0;
};

// UnityEngine.XR.ARSubsystems.ConfigurationDescriptor
struct ConfigurationDescriptor_tD16AA30B812AA662D234FBFE6575AF8A328CA3A1 
{
	// System.IntPtr UnityEngine.XR.ARSubsystems.ConfigurationDescriptor::m_Identifier
	intptr_t ___m_Identifier_0;
	// UnityEngine.XR.ARSubsystems.Feature UnityEngine.XR.ARSubsystems.ConfigurationDescriptor::m_Capabilities
	uint64_t ___m_Capabilities_1;
	// System.Int32 UnityEngine.XR.ARSubsystems.ConfigurationDescriptor::m_Rank
	int32_t ___m_Rank_2;
};

// System.Reflection.CustomAttributeNamedArgument
struct CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02 
{
	// System.Reflection.CustomAttributeTypedArgument System.Reflection.CustomAttributeNamedArgument::<TypedValue>k__BackingField
	CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F ___U3CTypedValueU3Ek__BackingField_0;
	// System.Boolean System.Reflection.CustomAttributeNamedArgument::<IsField>k__BackingField
	bool ___U3CIsFieldU3Ek__BackingField_1;
	// System.String System.Reflection.CustomAttributeNamedArgument::<MemberName>k__BackingField
	String_t* ___U3CMemberNameU3Ek__BackingField_2;
	// System.Type System.Reflection.CustomAttributeNamedArgument::_attributeType
	Type_t* ____attributeType_3;
	// System.Reflection.MemberInfo modreq(System.Runtime.CompilerServices.IsVolatile) System.Reflection.CustomAttributeNamedArgument::_lazyMemberInfo
	MemberInfo_t* ____lazyMemberInfo_4;
};
// Native definition for P/Invoke marshalling of System.Reflection.CustomAttributeNamedArgument
struct CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02_marshaled_pinvoke
{
	CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F_marshaled_pinvoke ___U3CTypedValueU3Ek__BackingField_0;
	int32_t ___U3CIsFieldU3Ek__BackingField_1;
	char* ___U3CMemberNameU3Ek__BackingField_2;
	Type_t* ____attributeType_3;
	MemberInfo_t* ____lazyMemberInfo_4;
};
// Native definition for COM marshalling of System.Reflection.CustomAttributeNamedArgument
struct CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02_marshaled_com
{
	CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F_marshaled_com ___U3CTypedValueU3Ek__BackingField_0;
	int32_t ___U3CIsFieldU3Ek__BackingField_1;
	Il2CppChar* ___U3CMemberNameU3Ek__BackingField_2;
	Type_t* ____attributeType_3;
	MemberInfo_t* ____lazyMemberInfo_4;
};

// UnityEngine.Profiling.Experimental.DebugScreenCapture
struct DebugScreenCapture_t859E4E87C94587A08893C726D4FF84BD8F288CC5 
{
	// Unity.Collections.NativeArray`1<System.Byte> UnityEngine.Profiling.Experimental.DebugScreenCapture::<rawImageDataReference>k__BackingField
	NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF ___U3CrawImageDataReferenceU3Ek__BackingField_0;
	// UnityEngine.TextureFormat UnityEngine.Profiling.Experimental.DebugScreenCapture::<imageFormat>k__BackingField
	int32_t ___U3CimageFormatU3Ek__BackingField_1;
	// System.Int32 UnityEngine.Profiling.Experimental.DebugScreenCapture::<width>k__BackingField
	int32_t ___U3CwidthU3Ek__BackingField_2;
	// System.Int32 UnityEngine.Profiling.Experimental.DebugScreenCapture::<height>k__BackingField
	int32_t ___U3CheightU3Ek__BackingField_3;
};

// Unity.Jobs.JobHandle
struct JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 
{
	// System.IntPtr Unity.Jobs.JobHandle::jobGroup
	intptr_t ___jobGroup_0;
	// System.Int32 Unity.Jobs.JobHandle::version
	int32_t ___version_1;
};

// UnityEngine.Rendering.LODParameters
struct LODParameters_t54D2AA0FD8E53BCF51D7A42BC1A72FCA8C78A08A 
{
	// System.Int32 UnityEngine.Rendering.LODParameters::m_IsOrthographic
	int32_t ___m_IsOrthographic_0;
	// UnityEngine.Vector3 UnityEngine.Rendering.LODParameters::m_CameraPosition
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_CameraPosition_1;
	// System.Single UnityEngine.Rendering.LODParameters::m_FieldOfView
	float ___m_FieldOfView_2;
	// System.Single UnityEngine.Rendering.LODParameters::m_OrthoSize
	float ___m_OrthoSize_3;
	// System.Int32 UnityEngine.Rendering.LODParameters::m_CameraPixelHeight
	int32_t ___m_CameraPixelHeight_4;
};

// UnityEngine.XR.MeshGenerationResult
struct MeshGenerationResult_tD5A6D639B2CF1A3F855AFB41861DEC48DC0D3A9C 
{
	// UnityEngine.XR.MeshId UnityEngine.XR.MeshGenerationResult::<MeshId>k__BackingField
	MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC ___U3CMeshIdU3Ek__BackingField_0;
	// UnityEngine.Mesh UnityEngine.XR.MeshGenerationResult::<Mesh>k__BackingField
	Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4* ___U3CMeshU3Ek__BackingField_1;
	// UnityEngine.MeshCollider UnityEngine.XR.MeshGenerationResult::<MeshCollider>k__BackingField
	MeshCollider_tB525E4DDE383252364ED0BDD32CF2B53914EE455* ___U3CMeshColliderU3Ek__BackingField_2;
	// UnityEngine.XR.MeshGenerationStatus UnityEngine.XR.MeshGenerationResult::<Status>k__BackingField
	int32_t ___U3CStatusU3Ek__BackingField_3;
	// UnityEngine.XR.MeshVertexAttributes UnityEngine.XR.MeshGenerationResult::<Attributes>k__BackingField
	int32_t ___U3CAttributesU3Ek__BackingField_4;
	// System.UInt64 UnityEngine.XR.MeshGenerationResult::<Timestamp>k__BackingField
	uint64_t ___U3CTimestampU3Ek__BackingField_5;
	// UnityEngine.Vector3 UnityEngine.XR.MeshGenerationResult::<Position>k__BackingField
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CPositionU3Ek__BackingField_6;
	// UnityEngine.Quaternion UnityEngine.XR.MeshGenerationResult::<Rotation>k__BackingField
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___U3CRotationU3Ek__BackingField_7;
	// UnityEngine.Vector3 UnityEngine.XR.MeshGenerationResult::<Scale>k__BackingField
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CScaleU3Ek__BackingField_8;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.MeshGenerationResult
struct MeshGenerationResult_tD5A6D639B2CF1A3F855AFB41861DEC48DC0D3A9C_marshaled_pinvoke
{
	MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC ___U3CMeshIdU3Ek__BackingField_0;
	Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4* ___U3CMeshU3Ek__BackingField_1;
	MeshCollider_tB525E4DDE383252364ED0BDD32CF2B53914EE455* ___U3CMeshColliderU3Ek__BackingField_2;
	int32_t ___U3CStatusU3Ek__BackingField_3;
	int32_t ___U3CAttributesU3Ek__BackingField_4;
	uint64_t ___U3CTimestampU3Ek__BackingField_5;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CPositionU3Ek__BackingField_6;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___U3CRotationU3Ek__BackingField_7;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CScaleU3Ek__BackingField_8;
};
// Native definition for COM marshalling of UnityEngine.XR.MeshGenerationResult
struct MeshGenerationResult_tD5A6D639B2CF1A3F855AFB41861DEC48DC0D3A9C_marshaled_com
{
	MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC ___U3CMeshIdU3Ek__BackingField_0;
	Mesh_t6D9C539763A09BC2B12AEAEF36F6DFFC98AE63D4* ___U3CMeshU3Ek__BackingField_1;
	MeshCollider_tB525E4DDE383252364ED0BDD32CF2B53914EE455* ___U3CMeshColliderU3Ek__BackingField_2;
	int32_t ___U3CStatusU3Ek__BackingField_3;
	int32_t ___U3CAttributesU3Ek__BackingField_4;
	uint64_t ___U3CTimestampU3Ek__BackingField_5;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CPositionU3Ek__BackingField_6;
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___U3CRotationU3Ek__BackingField_7;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CScaleU3Ek__BackingField_8;
};

// UnityEngine.XR.MeshInfo
struct MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA 
{
	// UnityEngine.XR.MeshId UnityEngine.XR.MeshInfo::<MeshId>k__BackingField
	MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC ___U3CMeshIdU3Ek__BackingField_0;
	// UnityEngine.XR.MeshChangeState UnityEngine.XR.MeshInfo::<ChangeState>k__BackingField
	int32_t ___U3CChangeStateU3Ek__BackingField_1;
	// System.Int32 UnityEngine.XR.MeshInfo::<PriorityHint>k__BackingField
	int32_t ___U3CPriorityHintU3Ek__BackingField_2;
};

// UnityEngine.XR.MeshTransform
struct MeshTransform_t669BDD0278EB7AC2976F16FD341CC1C4747FAA6A 
{
	// UnityEngine.XR.MeshId UnityEngine.XR.MeshTransform::<MeshId>k__BackingField
	MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC ___U3CMeshIdU3Ek__BackingField_0;
	// System.UInt64 UnityEngine.XR.MeshTransform::<Timestamp>k__BackingField
	uint64_t ___U3CTimestampU3Ek__BackingField_1;
	// UnityEngine.Vector3 UnityEngine.XR.MeshTransform::<Position>k__BackingField
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CPositionU3Ek__BackingField_2;
	// UnityEngine.Quaternion UnityEngine.XR.MeshTransform::<Rotation>k__BackingField
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___U3CRotationU3Ek__BackingField_3;
	// UnityEngine.Vector3 UnityEngine.XR.MeshTransform::<Scale>k__BackingField
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___U3CScaleU3Ek__BackingField_4;
};

// UnityEngine.Playables.PlayableGraph
struct PlayableGraph_t4A5B0B45343A240F0761574FD7C672E0CFFF7A6E 
{
	// System.IntPtr UnityEngine.Playables.PlayableGraph::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableGraph::m_Version
	uint32_t ___m_Version_1;
};

// UnityEngine.Playables.PlayableHandle
struct PlayableHandle_t5D6A01EF94382EFEDC047202F71DF882769654D4 
{
	// System.IntPtr UnityEngine.Playables.PlayableHandle::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableHandle::m_Version
	uint32_t ___m_Version_1;
};

struct PlayableHandle_t5D6A01EF94382EFEDC047202F71DF882769654D4_StaticFields
{
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.PlayableHandle::m_Null
	PlayableHandle_t5D6A01EF94382EFEDC047202F71DF882769654D4 ___m_Null_2;
};

// UnityEngine.Playables.PlayableOutputHandle
struct PlayableOutputHandle_tEB217645A8C0356A3AC6F964F283003B9740E883 
{
	// System.IntPtr UnityEngine.Playables.PlayableOutputHandle::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableOutputHandle::m_Version
	uint32_t ___m_Version_1;
};

struct PlayableOutputHandle_tEB217645A8C0356A3AC6F964F283003B9740E883_StaticFields
{
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutputHandle::m_Null
	PlayableOutputHandle_tEB217645A8C0356A3AC6F964F283003B9740E883 ___m_Null_2;
};

// UnityEngine.Pose
struct Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 
{
	// UnityEngine.Vector3 UnityEngine.Pose::position
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___position_0;
	// UnityEngine.Quaternion UnityEngine.Pose::rotation
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___rotation_1;
};

struct Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971_StaticFields
{
	// UnityEngine.Pose UnityEngine.Pose::k_Identity
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___k_Identity_2;
};

// UnityEngine.Ray
struct Ray_t2B1742D7958DC05BDC3EFC7461D3593E1430DC00 
{
	// UnityEngine.Vector3 UnityEngine.Ray::m_Origin
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Origin_0;
	// UnityEngine.Vector3 UnityEngine.Ray::m_Direction
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Direction_1;
};

// System.RuntimeFieldHandle
struct RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 
{
	// System.IntPtr System.RuntimeFieldHandle::value
	intptr_t ___value_0;
};

// System.RuntimeMethodHandle
struct RuntimeMethodHandle_tB35B96E97214DCBE20B0B02B1E687884B34680B2 
{
	// System.IntPtr System.RuntimeMethodHandle::value
	intptr_t ___value_0;
};

// System.RuntimeTypeHandle
struct RuntimeTypeHandle_t332A452B8B6179E4469B69525D0FE82A88030F7B 
{
	// System.IntPtr System.RuntimeTypeHandle::value
	intptr_t ___value_0;
};

// UnityEngine.Rendering.ScriptableRenderContext
struct ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36 
{
	// System.IntPtr UnityEngine.Rendering.ScriptableRenderContext::m_Ptr
	intptr_t ___m_Ptr_1;
};

struct ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36_StaticFields
{
	// UnityEngine.Rendering.ShaderTagId UnityEngine.Rendering.ScriptableRenderContext::kRenderTypeTag
	ShaderTagId_t453E2085B5EE9448FF75E550CAB111EFF690ECB0 ___kRenderTypeTag_0;
};

// UnityEngine.XR.ARSubsystems.XRCameraConfiguration
struct XRCameraConfiguration_t36D3B10519762ADD407F4A4F171D120CE2B3BD63 
{
	// UnityEngine.Vector2Int UnityEngine.XR.ARSubsystems.XRCameraConfiguration::m_Resolution
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___m_Resolution_0;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRCameraConfiguration::m_Framerate
	int32_t ___m_Framerate_1;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRCameraConfiguration::m_NativeConfigurationHandle
	intptr_t ___m_NativeConfigurationHandle_2;
	// UnityEngine.XR.ARSubsystems.Supported UnityEngine.XR.ARSubsystems.XRCameraConfiguration::m_DepthSensorSupported
	int32_t ___m_DepthSensorSupported_3;
};

// UnityEngine.XR.ARSubsystems.XRCpuImage
struct XRCpuImage_t36F512AD65D5B0AA1CC458C3666873D741C60A57 
{
	// System.Int32 UnityEngine.XR.ARSubsystems.XRCpuImage::m_NativeHandle
	int32_t ___m_NativeHandle_0;
	// UnityEngine.XR.ARSubsystems.XRCpuImage/Api UnityEngine.XR.ARSubsystems.XRCpuImage::m_Api
	Api_tAE210A8378E537AFD1FA4B99562229CE842377FB* ___m_Api_1;
	// UnityEngine.Vector2Int UnityEngine.XR.ARSubsystems.XRCpuImage::<dimensions>k__BackingField
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___U3CdimensionsU3Ek__BackingField_3;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRCpuImage::<planeCount>k__BackingField
	int32_t ___U3CplaneCountU3Ek__BackingField_4;
	// UnityEngine.XR.ARSubsystems.XRCpuImage/Format UnityEngine.XR.ARSubsystems.XRCpuImage::<format>k__BackingField
	int32_t ___U3CformatU3Ek__BackingField_5;
	// System.Double UnityEngine.XR.ARSubsystems.XRCpuImage::<timestamp>k__BackingField
	double ___U3CtimestampU3Ek__BackingField_6;
};

struct XRCpuImage_t36F512AD65D5B0AA1CC458C3666873D741C60A57_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRCpuImage/Api/OnImageRequestCompleteDelegate UnityEngine.XR.ARSubsystems.XRCpuImage::s_OnAsyncConversionCompleteDelegate
	OnImageRequestCompleteDelegate_tCD7B27E0C5D492FB984F05869FB527372CB70995* ___s_OnAsyncConversionCompleteDelegate_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARSubsystems.XRCpuImage
struct XRCpuImage_t36F512AD65D5B0AA1CC458C3666873D741C60A57_marshaled_pinvoke
{
	int32_t ___m_NativeHandle_0;
	Api_tAE210A8378E537AFD1FA4B99562229CE842377FB* ___m_Api_1;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___U3CdimensionsU3Ek__BackingField_3;
	int32_t ___U3CplaneCountU3Ek__BackingField_4;
	int32_t ___U3CformatU3Ek__BackingField_5;
	double ___U3CtimestampU3Ek__BackingField_6;
};
// Native definition for COM marshalling of UnityEngine.XR.ARSubsystems.XRCpuImage
struct XRCpuImage_t36F512AD65D5B0AA1CC458C3666873D741C60A57_marshaled_com
{
	int32_t ___m_NativeHandle_0;
	Api_tAE210A8378E537AFD1FA4B99562229CE842377FB* ___m_Api_1;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___U3CdimensionsU3Ek__BackingField_3;
	int32_t ___U3CplaneCountU3Ek__BackingField_4;
	int32_t ___U3CformatU3Ek__BackingField_5;
	double ___U3CtimestampU3Ek__BackingField_6;
};

// UnityEngine.XR.ARSubsystems.XRHumanBodyPose2DJoint
struct XRHumanBodyPose2DJoint_t9674B917C7629002A302E572CABC8ACED71EFF26 
{
	// System.Int32 UnityEngine.XR.ARSubsystems.XRHumanBodyPose2DJoint::m_Index
	int32_t ___m_Index_0;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRHumanBodyPose2DJoint::m_ParentIndex
	int32_t ___m_ParentIndex_1;
	// UnityEngine.Vector2 UnityEngine.XR.ARSubsystems.XRHumanBodyPose2DJoint::m_Position
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Position_2;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRHumanBodyPose2DJoint::m_Tracked
	int32_t ___m_Tracked_3;
};

// UnityEngine.XR.XRNodeState
struct XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A 
{
	// UnityEngine.XR.XRNode UnityEngine.XR.XRNodeState::m_Type
	int32_t ___m_Type_0;
	// UnityEngine.XR.AvailableTrackingData UnityEngine.XR.XRNodeState::m_AvailableFields
	int32_t ___m_AvailableFields_1;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_Position
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Position_2;
	// UnityEngine.Quaternion UnityEngine.XR.XRNodeState::m_Rotation
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___m_Rotation_3;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_Velocity
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Velocity_4;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_AngularVelocity
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_AngularVelocity_5;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_Acceleration
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Acceleration_6;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_AngularAcceleration
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_AngularAcceleration_7;
	// System.Int32 UnityEngine.XR.XRNodeState::m_Tracked
	int32_t ___m_Tracked_8;
	// System.UInt64 UnityEngine.XR.XRNodeState::m_UniqueID
	uint64_t ___m_UniqueID_9;
};

// UnityEngine.XR.ARSubsystems.XRPointCloudData
struct XRPointCloudData_t06BF6FA78C7ED8CBDCAAAFAC6548A309860E7C5B 
{
	// Unity.Collections.NativeArray`1<UnityEngine.Vector3> UnityEngine.XR.ARSubsystems.XRPointCloudData::m_Positions
	NativeArray_1_t97E2BFD61E13EEF2CDE34A313415FAD03AB993FD ___m_Positions_0;
	// Unity.Collections.NativeArray`1<System.Single> UnityEngine.XR.ARSubsystems.XRPointCloudData::m_ConfidenceValues
	NativeArray_1_t3848EE4B6647317212A754634DE6DBC90B99FBEF ___m_ConfidenceValues_1;
	// Unity.Collections.NativeArray`1<System.UInt64> UnityEngine.XR.ARSubsystems.XRPointCloudData::m_Identifiers
	NativeArray_1_t07975297AD7F7512193094A7C0703BA872EF7A7B ___m_Identifiers_2;
};

// UnityEngine.XR.ARSubsystems.XRReferenceImage
struct XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F 
{
	// UnityEngine.XR.ARSubsystems.SerializableGuid UnityEngine.XR.ARSubsystems.XRReferenceImage::m_SerializedGuid
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___m_SerializedGuid_0;
	// UnityEngine.XR.ARSubsystems.SerializableGuid UnityEngine.XR.ARSubsystems.XRReferenceImage::m_SerializedTextureGuid
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___m_SerializedTextureGuid_1;
	// UnityEngine.Vector2 UnityEngine.XR.ARSubsystems.XRReferenceImage::m_Size
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Size_2;
	// System.Boolean UnityEngine.XR.ARSubsystems.XRReferenceImage::m_SpecifySize
	bool ___m_SpecifySize_3;
	// System.String UnityEngine.XR.ARSubsystems.XRReferenceImage::m_Name
	String_t* ___m_Name_4;
	// UnityEngine.Texture2D UnityEngine.XR.ARSubsystems.XRReferenceImage::m_Texture
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___m_Texture_5;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARSubsystems.XRReferenceImage
struct XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F_marshaled_pinvoke
{
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___m_SerializedGuid_0;
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___m_SerializedTextureGuid_1;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Size_2;
	int32_t ___m_SpecifySize_3;
	char* ___m_Name_4;
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___m_Texture_5;
};
// Native definition for COM marshalling of UnityEngine.XR.ARSubsystems.XRReferenceImage
struct XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F_marshaled_com
{
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___m_SerializedGuid_0;
	SerializableGuid_tCEABDCED6CD954AC100159BDEFC5D414049C0378 ___m_SerializedTextureGuid_1;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Size_2;
	int32_t ___m_SpecifySize_3;
	Il2CppChar* ___m_Name_4;
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___m_Texture_5;
};

// UnityEngine.XR.ARSubsystems.XRSessionUpdateParams
struct XRSessionUpdateParams_t7E03F47CA8C7ACECDA528B8F260C2EDD9D1C12F1 
{
	// UnityEngine.ScreenOrientation UnityEngine.XR.ARSubsystems.XRSessionUpdateParams::<screenOrientation>k__BackingField
	int32_t ___U3CscreenOrientationU3Ek__BackingField_0;
	// UnityEngine.Vector2Int UnityEngine.XR.ARSubsystems.XRSessionUpdateParams::<screenDimensions>k__BackingField
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___U3CscreenDimensionsU3Ek__BackingField_1;
};

// UnityEngine.XR.ARSubsystems.XRTextureDescriptor
struct XRTextureDescriptor_t699023EDE6E2593F61CE969A68B5E56CD04CFA19 
{
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_NativeTexture
	intptr_t ___m_NativeTexture_0;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_Width
	int32_t ___m_Width_1;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_Height
	int32_t ___m_Height_2;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_MipmapCount
	int32_t ___m_MipmapCount_3;
	// UnityEngine.TextureFormat UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_Format
	int32_t ___m_Format_4;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_PropertyNameId
	int32_t ___m_PropertyNameId_5;
	// System.Int32 UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_Depth
	int32_t ___m_Depth_6;
	// UnityEngine.Rendering.TextureDimension UnityEngine.XR.ARSubsystems.XRTextureDescriptor::m_Dimension
	int32_t ___m_Dimension_7;
};

// UnityEngine.XR.ARSubsystems.XRCpuImage/ConversionParams
struct ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 
{
	// UnityEngine.RectInt UnityEngine.XR.ARSubsystems.XRCpuImage/ConversionParams::m_InputRect
	RectInt_t1744D10E1063135DA9D574F95205B98DAC600CB8 ___m_InputRect_0;
	// UnityEngine.Vector2Int UnityEngine.XR.ARSubsystems.XRCpuImage/ConversionParams::m_OutputDimensions
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___m_OutputDimensions_1;
	// UnityEngine.TextureFormat UnityEngine.XR.ARSubsystems.XRCpuImage/ConversionParams::m_Format
	int32_t ___m_Format_2;
	// UnityEngine.XR.ARSubsystems.XRCpuImage/Transformation UnityEngine.XR.ARSubsystems.XRCpuImage/ConversionParams::m_Transformation
	int32_t ___m_Transformation_3;
};

// System.Nullable`1<UnityEngine.XR.ARSubsystems.XRCameraConfiguration>
struct Nullable_1_t4F11BA1306120798159EC97ABA03E6731032A09F 
{
	// System.Boolean System.Nullable`1::hasValue
	bool ___hasValue_0;
	// T System.Nullable`1::value
	XRCameraConfiguration_t36D3B10519762ADD407F4A4F171D120CE2B3BD63 ___value_1;
};

// System.ReadOnlySpan`1<System.Byte>
struct ReadOnlySpan_1_tA850A6C0E88ABBA37646A078ACBC24D6D5FD9B4D 
{
	// System.ByReference`1<T> System.ReadOnlySpan`1::_pointer
	ByReference_1_t9C85BCCAAF8C525B6C06B07E922D8D217BE8D6FC ____pointer_0;
	// System.Int32 System.ReadOnlySpan`1::_length
	int32_t ____length_1;
};

// System.ReadOnlySpan`1<System.Char>
struct ReadOnlySpan_1_t59614EA6E51A945A32B02AB17FBCBDF9A5C419C1 
{
	// System.ByReference`1<T> System.ReadOnlySpan`1::_pointer
	ByReference_1_t7BA5A6CA164F770BC688F21C5978D368716465F5 ____pointer_0;
	// System.Int32 System.ReadOnlySpan`1::_length
	int32_t ____length_1;
};

// System.Span`1<System.Byte>
struct Span_1_tDADAC65069DFE6B57C458109115ECD795ED39305 
{
	// System.ByReference`1<T> System.Span`1::_pointer
	ByReference_1_t9C85BCCAAF8C525B6C06B07E922D8D217BE8D6FC ____pointer_0;
	// System.Int32 System.Span`1::_length
	int32_t ____length_1;
};

// System.Span`1<System.Char>
struct Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D 
{
	// System.ByReference`1<T> System.Span`1::_pointer
	ByReference_1_t7BA5A6CA164F770BC688F21C5978D368716465F5 ____pointer_0;
	// System.Int32 System.Span`1::_length
	int32_t ____length_1;
};

// UnityEngine.XR.ARCore.ARCoreBeforeGetCameraConfigurationEventArgs
struct ARCoreBeforeGetCameraConfigurationEventArgs_t9368C5A015241C02E50D864D77FDFC2D223FA451 
{
	// UnityEngine.XR.ARCore.ArSession UnityEngine.XR.ARCore.ARCoreBeforeGetCameraConfigurationEventArgs::<session>k__BackingField
	ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF ___U3CsessionU3Ek__BackingField_0;
	// UnityEngine.XR.ARCore.ArCameraConfigFilter UnityEngine.XR.ARCore.ARCoreBeforeGetCameraConfigurationEventArgs::<filter>k__BackingField
	ArCameraConfigFilter_tF665AEAE3CDEB76E6485508096A093A9E0E0B607 ___U3CfilterU3Ek__BackingField_1;
};

// UnityEngine.XR.ARCore.ARCoreBeforeSetConfigurationEventArgs
struct ARCoreBeforeSetConfigurationEventArgs_tF91B773E2C89D6954A1C4332EDC8FA09A5E22938 
{
	// UnityEngine.XR.ARCore.ArSession UnityEngine.XR.ARCore.ARCoreBeforeSetConfigurationEventArgs::m_Session
	ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF ___m_Session_0;
	// UnityEngine.XR.ARCore.ArConfig UnityEngine.XR.ARCore.ARCoreBeforeSetConfigurationEventArgs::m_Config
	ArConfig_tC991F7E3046E638B111BDBE5A2B25C4F363C4F1C ___m_Config_1;
};

// UnityEngine.XR.ARFoundation.ARLightEstimationData
struct ARLightEstimationData_tE622C47E05EBA84E05326E72C9D258F0200D5CE7 
{
	// System.Nullable`1<System.Single> UnityEngine.XR.ARFoundation.ARLightEstimationData::<averageColorTemperature>k__BackingField
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CaverageColorTemperatureU3Ek__BackingField_0;
	// System.Nullable`1<UnityEngine.Color> UnityEngine.XR.ARFoundation.ARLightEstimationData::<colorCorrection>k__BackingField
	Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 ___U3CcolorCorrectionU3Ek__BackingField_1;
	// System.Nullable`1<System.Single> UnityEngine.XR.ARFoundation.ARLightEstimationData::<mainLightIntensityLumens>k__BackingField
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CmainLightIntensityLumensU3Ek__BackingField_2;
	// System.Nullable`1<UnityEngine.Color> UnityEngine.XR.ARFoundation.ARLightEstimationData::<mainLightColor>k__BackingField
	Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 ___U3CmainLightColorU3Ek__BackingField_3;
	// System.Nullable`1<UnityEngine.Vector3> UnityEngine.XR.ARFoundation.ARLightEstimationData::<mainLightDirection>k__BackingField
	Nullable_1_t9C51B084784B716FFF4ED4575C63CFD8A71A86FE ___U3CmainLightDirectionU3Ek__BackingField_4;
	// System.Nullable`1<UnityEngine.Rendering.SphericalHarmonicsL2> UnityEngine.XR.ARFoundation.ARLightEstimationData::<ambientSphericalHarmonics>k__BackingField
	Nullable_1_t4C9CB95ACA9906A61C759884064F60858BF7E798 ___U3CambientSphericalHarmonicsU3Ek__BackingField_5;
	// System.Nullable`1<System.Single> UnityEngine.XR.ARFoundation.ARLightEstimationData::m_AverageBrightness
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_AverageBrightness_6;
	// System.Nullable`1<System.Single> UnityEngine.XR.ARFoundation.ARLightEstimationData::m_AverageIntensityInLumens
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_AverageIntensityInLumens_7;
	// System.Nullable`1<System.Single> UnityEngine.XR.ARFoundation.ARLightEstimationData::m_MainLightBrightness
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_MainLightBrightness_8;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARLightEstimationData
struct ARLightEstimationData_tE622C47E05EBA84E05326E72C9D258F0200D5CE7_marshaled_pinvoke
{
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CaverageColorTemperatureU3Ek__BackingField_0;
	Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 ___U3CcolorCorrectionU3Ek__BackingField_1;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CmainLightIntensityLumensU3Ek__BackingField_2;
	Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 ___U3CmainLightColorU3Ek__BackingField_3;
	Nullable_1_t9C51B084784B716FFF4ED4575C63CFD8A71A86FE ___U3CmainLightDirectionU3Ek__BackingField_4;
	Nullable_1_t4C9CB95ACA9906A61C759884064F60858BF7E798 ___U3CambientSphericalHarmonicsU3Ek__BackingField_5;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_AverageBrightness_6;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_AverageIntensityInLumens_7;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_MainLightBrightness_8;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARLightEstimationData
struct ARLightEstimationData_tE622C47E05EBA84E05326E72C9D258F0200D5CE7_marshaled_com
{
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CaverageColorTemperatureU3Ek__BackingField_0;
	Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 ___U3CcolorCorrectionU3Ek__BackingField_1;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CmainLightIntensityLumensU3Ek__BackingField_2;
	Nullable_1_tEE83D90B507D40B6C58B5EEF5B9D44D377B44F11 ___U3CmainLightColorU3Ek__BackingField_3;
	Nullable_1_t9C51B084784B716FFF4ED4575C63CFD8A71A86FE ___U3CmainLightDirectionU3Ek__BackingField_4;
	Nullable_1_t4C9CB95ACA9906A61C759884064F60858BF7E798 ___U3CambientSphericalHarmonicsU3Ek__BackingField_5;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_AverageBrightness_6;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_AverageIntensityInLumens_7;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___m_MainLightBrightness_8;
};

// UnityEngine.XR.ARFoundation.ARTextureInfo
struct ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 
{
	// UnityEngine.XR.ARSubsystems.XRTextureDescriptor UnityEngine.XR.ARFoundation.ARTextureInfo::m_Descriptor
	XRTextureDescriptor_t699023EDE6E2593F61CE969A68B5E56CD04CFA19 ___m_Descriptor_1;
	// UnityEngine.Texture UnityEngine.XR.ARFoundation.ARTextureInfo::m_Texture
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_Texture_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARTextureInfo
struct ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261_marshaled_pinvoke
{
	XRTextureDescriptor_t699023EDE6E2593F61CE969A68B5E56CD04CFA19 ___m_Descriptor_1;
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_Texture_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARTextureInfo
struct ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261_marshaled_com
{
	XRTextureDescriptor_t699023EDE6E2593F61CE969A68B5E56CD04CFA19 ___m_Descriptor_1;
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_Texture_2;
};

// UnityEngine.XR.ARSubsystems.AddReferenceImageJobState
struct AddReferenceImageJobState_tCF90A84092F3D2A7536D1D28C9E6EC0D7F53937A 
{
	// System.IntPtr UnityEngine.XR.ARSubsystems.AddReferenceImageJobState::m_Handle
	intptr_t ___m_Handle_0;
	// UnityEngine.XR.ARSubsystems.MutableRuntimeReferenceImageLibrary UnityEngine.XR.ARSubsystems.AddReferenceImageJobState::m_Library
	MutableRuntimeReferenceImageLibrary_t51AE6E77B281FCE9DF42C7E905A11935708A53F8* ___m_Library_1;
	// Unity.Jobs.JobHandle UnityEngine.XR.ARSubsystems.AddReferenceImageJobState::<jobHandle>k__BackingField
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 ___U3CjobHandleU3Ek__BackingField_2;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARSubsystems.AddReferenceImageJobState
struct AddReferenceImageJobState_tCF90A84092F3D2A7536D1D28C9E6EC0D7F53937A_marshaled_pinvoke
{
	intptr_t ___m_Handle_0;
	MutableRuntimeReferenceImageLibrary_t51AE6E77B281FCE9DF42C7E905A11935708A53F8* ___m_Library_1;
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 ___U3CjobHandleU3Ek__BackingField_2;
};
// Native definition for COM marshalling of UnityEngine.XR.ARSubsystems.AddReferenceImageJobState
struct AddReferenceImageJobState_tCF90A84092F3D2A7536D1D28C9E6EC0D7F53937A_marshaled_com
{
	intptr_t ___m_Handle_0;
	MutableRuntimeReferenceImageLibrary_t51AE6E77B281FCE9DF42C7E905A11935708A53F8* ___m_Library_1;
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 ___U3CjobHandleU3Ek__BackingField_2;
};

// UnityEngine.Rendering.BatchCullingContext
struct BatchCullingContext_t6133D8CF3B9A93AED429E017C62DC2F5BD64A659 
{
	// Unity.Collections.NativeArray`1<UnityEngine.Plane> UnityEngine.Rendering.BatchCullingContext::cullingPlanes
	NativeArray_1_t4020B6981295FB915DCE82EF368535F680C13A49 ___cullingPlanes_0;
	// Unity.Collections.NativeArray`1<UnityEngine.Rendering.CullingSplit> UnityEngine.Rendering.BatchCullingContext::cullingSplits
	NativeArray_1_t73992261AA60020B6BE20D83C50B3F925CC89F31 ___cullingSplits_1;
	// UnityEngine.Rendering.LODParameters UnityEngine.Rendering.BatchCullingContext::lodParameters
	LODParameters_t54D2AA0FD8E53BCF51D7A42BC1A72FCA8C78A08A ___lodParameters_2;
	// UnityEngine.Matrix4x4 UnityEngine.Rendering.BatchCullingContext::cullingMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___cullingMatrix_3;
	// UnityEngine.Matrix4x4 UnityEngine.Rendering.BatchCullingContext::localToWorldMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___localToWorldMatrix_4;
	// UnityEngine.Rendering.BatchCullingViewType UnityEngine.Rendering.BatchCullingContext::viewType
	int32_t ___viewType_5;
	// UnityEngine.Rendering.BatchPackedCullingViewID UnityEngine.Rendering.BatchCullingContext::viewID
	BatchPackedCullingViewID_t1E7EE8631C02555CAA181FA566CDC604B9FEFEBB ___viewID_6;
	// System.UInt32 UnityEngine.Rendering.BatchCullingContext::cullingLayerMask
	uint32_t ___cullingLayerMask_7;
	// System.UInt64 UnityEngine.Rendering.BatchCullingContext::sceneCullingMask
	uint64_t ___sceneCullingMask_8;
	// System.Byte UnityEngine.Rendering.BatchCullingContext::isOrthographic
	uint8_t ___isOrthographic_9;
	// System.Int32 UnityEngine.Rendering.BatchCullingContext::receiverPlaneOffset
	int32_t ___receiverPlaneOffset_10;
	// System.Int32 UnityEngine.Rendering.BatchCullingContext::receiverPlaneCount
	int32_t ___receiverPlaneCount_11;
};

// UnityEngine.XR.ARSubsystems.BoundedPlane
struct BoundedPlane_tF51C315A8961EB42F0A1B60D47158646E5AF75CE 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.BoundedPlane::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_1;
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.BoundedPlane::m_SubsumedById
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_SubsumedById_2;
	// UnityEngine.Vector2 UnityEngine.XR.ARSubsystems.BoundedPlane::m_Center
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Center_3;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.BoundedPlane::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_4;
	// UnityEngine.Vector2 UnityEngine.XR.ARSubsystems.BoundedPlane::m_Size
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Size_5;
	// UnityEngine.XR.ARSubsystems.PlaneAlignment UnityEngine.XR.ARSubsystems.BoundedPlane::m_Alignment
	int32_t ___m_Alignment_6;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.BoundedPlane::m_TrackingState
	int32_t ___m_TrackingState_7;
	// System.IntPtr UnityEngine.XR.ARSubsystems.BoundedPlane::m_NativePtr
	intptr_t ___m_NativePtr_8;
	// UnityEngine.XR.ARSubsystems.PlaneClassification UnityEngine.XR.ARSubsystems.BoundedPlane::m_Classification
	int32_t ___m_Classification_9;
};

struct BoundedPlane_tF51C315A8961EB42F0A1B60D47158646E5AF75CE_StaticFields
{
	// UnityEngine.XR.ARSubsystems.BoundedPlane UnityEngine.XR.ARSubsystems.BoundedPlane::s_Default
	BoundedPlane_tF51C315A8961EB42F0A1B60D47158646E5AF75CE ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.Configuration
struct Configuration_tF3E68F5793D5A997146A65AEAAC9B062BCAF0947 
{
	// UnityEngine.XR.ARSubsystems.ConfigurationDescriptor UnityEngine.XR.ARSubsystems.Configuration::<descriptor>k__BackingField
	ConfigurationDescriptor_tD16AA30B812AA662D234FBFE6575AF8A328CA3A1 ___U3CdescriptorU3Ek__BackingField_0;
	// UnityEngine.XR.ARSubsystems.Feature UnityEngine.XR.ARSubsystems.Configuration::<features>k__BackingField
	uint64_t ___U3CfeaturesU3Ek__BackingField_1;
};

// UnityEngine.Playables.Playable
struct Playable_t95C6B795846BA0C7D96E4DA14897CCCF2554334F 
{
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.Playable::m_Handle
	PlayableHandle_t5D6A01EF94382EFEDC047202F71DF882769654D4 ___m_Handle_0;
};

struct Playable_t95C6B795846BA0C7D96E4DA14897CCCF2554334F_StaticFields
{
	// UnityEngine.Playables.Playable UnityEngine.Playables.Playable::m_NullPlayable
	Playable_t95C6B795846BA0C7D96E4DA14897CCCF2554334F ___m_NullPlayable_1;
};

// UnityEngine.Playables.PlayableOutput
struct PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 
{
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutput::m_Handle
	PlayableOutputHandle_tEB217645A8C0356A3AC6F964F283003B9740E883 ___m_Handle_0;
};

struct PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680_StaticFields
{
	// UnityEngine.Playables.PlayableOutput UnityEngine.Playables.PlayableOutput::m_NullPlayableOutput
	PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 ___m_NullPlayableOutput_1;
};

// System.TypedReference
struct TypedReference_tF20A82297BED597FD80BDA0E41F74746B0FD642B 
{
	// System.RuntimeTypeHandle System.TypedReference::type
	RuntimeTypeHandle_t332A452B8B6179E4469B69525D0FE82A88030F7B ___type_0;
	// System.IntPtr System.TypedReference::Value
	intptr_t ___Value_1;
	// System.IntPtr System.TypedReference::Type
	intptr_t ___Type_2;
};

// UnityEngine.XR.ARSubsystems.XRAnchor
struct XRAnchor_tDD427E66CAA09DE7B058EA76223EF7DC3880FE82 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRAnchor::m_Id
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_Id_1;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRAnchor::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_2;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRAnchor::m_TrackingState
	int32_t ___m_TrackingState_3;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRAnchor::m_NativePtr
	intptr_t ___m_NativePtr_4;
	// System.Guid UnityEngine.XR.ARSubsystems.XRAnchor::m_SessionId
	Guid_t ___m_SessionId_5;
};

struct XRAnchor_tDD427E66CAA09DE7B058EA76223EF7DC3880FE82_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRAnchor UnityEngine.XR.ARSubsystems.XRAnchor::s_Default
	XRAnchor_tDD427E66CAA09DE7B058EA76223EF7DC3880FE82 ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XREnvironmentProbe
struct XREnvironmentProbe_tAA657FAB648E2599B519F9FD66A1CEED65034DD9 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_1;
	// UnityEngine.Vector3 UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_Scale
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Scale_2;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_3;
	// UnityEngine.Vector3 UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_Size
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Size_4;
	// UnityEngine.XR.ARSubsystems.XRTextureDescriptor UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_TextureDescriptor
	XRTextureDescriptor_t699023EDE6E2593F61CE969A68B5E56CD04CFA19 ___m_TextureDescriptor_5;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_TrackingState
	int32_t ___m_TrackingState_6;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XREnvironmentProbe::m_NativePtr
	intptr_t ___m_NativePtr_7;
};

struct XREnvironmentProbe_tAA657FAB648E2599B519F9FD66A1CEED65034DD9_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XREnvironmentProbe UnityEngine.XR.ARSubsystems.XREnvironmentProbe::s_Default
	XREnvironmentProbe_tAA657FAB648E2599B519F9FD66A1CEED65034DD9 ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XRFace
struct XRFace_t235F951F4AC7CC6A0CA6829CECA05210D64982FB 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRFace::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_0;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRFace::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_1;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRFace::m_TrackingState
	int32_t ___m_TrackingState_2;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRFace::m_NativePtr
	intptr_t ___m_NativePtr_3;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRFace::m_LeftEyePose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_LeftEyePose_4;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRFace::m_RightEyePose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_RightEyePose_5;
	// UnityEngine.Vector3 UnityEngine.XR.ARSubsystems.XRFace::m_FixationPoint
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_FixationPoint_6;
};

struct XRFace_t235F951F4AC7CC6A0CA6829CECA05210D64982FB_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRFace UnityEngine.XR.ARSubsystems.XRFace::s_Default
	XRFace_t235F951F4AC7CC6A0CA6829CECA05210D64982FB ___s_Default_7;
};

// UnityEngine.XR.ARSubsystems.XRHumanBody
struct XRHumanBody_t88EF91F599A4F22EABB233F85DE7782EE8B86692 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRHumanBody::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_0;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRHumanBody::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_1;
	// System.Single UnityEngine.XR.ARSubsystems.XRHumanBody::m_EstimatedHeightScaleFactor
	float ___m_EstimatedHeightScaleFactor_2;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRHumanBody::m_TrackingState
	int32_t ___m_TrackingState_3;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRHumanBody::m_NativePtr
	intptr_t ___m_NativePtr_4;
};

struct XRHumanBody_t88EF91F599A4F22EABB233F85DE7782EE8B86692_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRHumanBody UnityEngine.XR.ARSubsystems.XRHumanBody::s_Default
	XRHumanBody_t88EF91F599A4F22EABB233F85DE7782EE8B86692 ___s_Default_5;
};

// UnityEngine.XR.ARSubsystems.XRParticipant
struct XRParticipant_t3885B841862D28B0509433D566F00FA3C3CD79E1 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRParticipant::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_0;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRParticipant::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_1;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRParticipant::m_TrackingState
	int32_t ___m_TrackingState_2;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRParticipant::m_NativePtr
	intptr_t ___m_NativePtr_3;
	// System.Guid UnityEngine.XR.ARSubsystems.XRParticipant::m_SessionId
	Guid_t ___m_SessionId_4;
};

struct XRParticipant_t3885B841862D28B0509433D566F00FA3C3CD79E1_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRParticipant UnityEngine.XR.ARSubsystems.XRParticipant::k_Default
	XRParticipant_t3885B841862D28B0509433D566F00FA3C3CD79E1 ___k_Default_5;
};

// UnityEngine.XR.ARSubsystems.XRPointCloud
struct XRPointCloud_t99DB921A9C92F53CEA3EB29A64E2DECDA6EA7D8C 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRPointCloud::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_1;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRPointCloud::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_2;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRPointCloud::m_TrackingState
	int32_t ___m_TrackingState_3;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRPointCloud::m_NativePtr
	intptr_t ___m_NativePtr_4;
};

struct XRPointCloud_t99DB921A9C92F53CEA3EB29A64E2DECDA6EA7D8C_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRPointCloud UnityEngine.XR.ARSubsystems.XRPointCloud::s_Default
	XRPointCloud_t99DB921A9C92F53CEA3EB29A64E2DECDA6EA7D8C ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XRRaycast
struct XRRaycast_t100015712885CDF4EF42820EB36277DC6DDC8103 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRRaycast::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_1;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRRaycast::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_2;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRRaycast::m_TrackingState
	int32_t ___m_TrackingState_3;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRRaycast::m_NativePtr
	intptr_t ___m_NativePtr_4;
	// System.Single UnityEngine.XR.ARSubsystems.XRRaycast::m_Distance
	float ___m_Distance_5;
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRRaycast::m_HitTrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_HitTrackableId_6;
};

struct XRRaycast_t100015712885CDF4EF42820EB36277DC6DDC8103_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRRaycast UnityEngine.XR.ARSubsystems.XRRaycast::s_Default
	XRRaycast_t100015712885CDF4EF42820EB36277DC6DDC8103 ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XRRaycastHit
struct XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRRaycastHit::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_1;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRRaycastHit::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_2;
	// System.Single UnityEngine.XR.ARSubsystems.XRRaycastHit::m_Distance
	float ___m_Distance_3;
	// UnityEngine.XR.ARSubsystems.TrackableType UnityEngine.XR.ARSubsystems.XRRaycastHit::m_HitType
	int32_t ___m_HitType_4;
};

struct XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRRaycastHit UnityEngine.XR.ARSubsystems.XRRaycastHit::s_Default
	XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XRReferencePoint
struct XRReferencePoint_t7B269D148483373FDE78B3262CF334C2D86B6291 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRReferencePoint::m_Id
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_Id_1;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRReferencePoint::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_2;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRReferencePoint::m_TrackingState
	int32_t ___m_TrackingState_3;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRReferencePoint::m_NativePtr
	intptr_t ___m_NativePtr_4;
	// System.Guid UnityEngine.XR.ARSubsystems.XRReferencePoint::m_SessionId
	Guid_t ___m_SessionId_5;
};

struct XRReferencePoint_t7B269D148483373FDE78B3262CF334C2D86B6291_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRReferencePoint UnityEngine.XR.ARSubsystems.XRReferencePoint::s_Default
	XRReferencePoint_t7B269D148483373FDE78B3262CF334C2D86B6291 ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XRTrackedImage
struct XRTrackedImage_t0F99DAB96B2D6422D0F8DA720F9BEFD3655DDFDD 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRTrackedImage::m_Id
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_Id_1;
	// System.Guid UnityEngine.XR.ARSubsystems.XRTrackedImage::m_SourceImageId
	Guid_t ___m_SourceImageId_2;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRTrackedImage::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_3;
	// UnityEngine.Vector2 UnityEngine.XR.ARSubsystems.XRTrackedImage::m_Size
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___m_Size_4;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRTrackedImage::m_TrackingState
	int32_t ___m_TrackingState_5;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRTrackedImage::m_NativePtr
	intptr_t ___m_NativePtr_6;
};

struct XRTrackedImage_t0F99DAB96B2D6422D0F8DA720F9BEFD3655DDFDD_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRTrackedImage UnityEngine.XR.ARSubsystems.XRTrackedImage::s_Default
	XRTrackedImage_t0F99DAB96B2D6422D0F8DA720F9BEFD3655DDFDD ___s_Default_0;
};

// UnityEngine.XR.ARSubsystems.XRTrackedObject
struct XRTrackedObject_t56B5A101A8698B5C95F2CBE93FCF0F8911B67E75 
{
	// UnityEngine.XR.ARSubsystems.TrackableId UnityEngine.XR.ARSubsystems.XRTrackedObject::m_TrackableId
	TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 ___m_TrackableId_0;
	// UnityEngine.Pose UnityEngine.XR.ARSubsystems.XRTrackedObject::m_Pose
	Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 ___m_Pose_1;
	// UnityEngine.XR.ARSubsystems.TrackingState UnityEngine.XR.ARSubsystems.XRTrackedObject::m_TrackingState
	int32_t ___m_TrackingState_2;
	// System.IntPtr UnityEngine.XR.ARSubsystems.XRTrackedObject::m_NativePtr
	intptr_t ___m_NativePtr_3;
	// System.Guid UnityEngine.XR.ARSubsystems.XRTrackedObject::m_ReferenceObjectGuid
	Guid_t ___m_ReferenceObjectGuid_4;
};

struct XRTrackedObject_t56B5A101A8698B5C95F2CBE93FCF0F8911B67E75_StaticFields
{
	// UnityEngine.XR.ARSubsystems.XRTrackedObject UnityEngine.XR.ARSubsystems.XRTrackedObject::s_Default
	XRTrackedObject_t56B5A101A8698B5C95F2CBE93FCF0F8911B67E75 ___s_Default_5;
};

// UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs
struct ARCameraFrameEventArgs_t4060608C37C2B7248AFC908876309CC36D53E0EC 
{
	// UnityEngine.XR.ARFoundation.ARLightEstimationData UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<lightEstimation>k__BackingField
	ARLightEstimationData_tE622C47E05EBA84E05326E72C9D258F0200D5CE7 ___U3ClightEstimationU3Ek__BackingField_0;
	// System.Nullable`1<System.Int64> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<timestampNs>k__BackingField
	Nullable_1_t365991B3904FDA7642A788423B28692FDC7CDB17 ___U3CtimestampNsU3Ek__BackingField_1;
	// System.Nullable`1<UnityEngine.Matrix4x4> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<projectionMatrix>k__BackingField
	Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA ___U3CprojectionMatrixU3Ek__BackingField_2;
	// System.Nullable`1<UnityEngine.Matrix4x4> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<displayMatrix>k__BackingField
	Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA ___U3CdisplayMatrixU3Ek__BackingField_3;
	// System.Collections.Generic.List`1<UnityEngine.Texture2D> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<textures>k__BackingField
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___U3CtexturesU3Ek__BackingField_4;
	// System.Collections.Generic.List`1<System.Int32> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<propertyNameIds>k__BackingField
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3CpropertyNameIdsU3Ek__BackingField_5;
	// System.Nullable`1<System.Double> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<exposureDuration>k__BackingField
	Nullable_1_t6E154519A812D040E3016229CD7638843A2CC165 ___U3CexposureDurationU3Ek__BackingField_6;
	// System.Nullable`1<System.Single> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<exposureOffset>k__BackingField
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CexposureOffsetU3Ek__BackingField_7;
	// System.Collections.Generic.List`1<System.String> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<enabledMaterialKeywords>k__BackingField
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CenabledMaterialKeywordsU3Ek__BackingField_8;
	// System.Collections.Generic.List`1<System.String> UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<disabledMaterialKeywords>k__BackingField
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CdisabledMaterialKeywordsU3Ek__BackingField_9;
	// UnityEngine.Texture UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<cameraGrainTexture>k__BackingField
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___U3CcameraGrainTextureU3Ek__BackingField_10;
	// System.Single UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs::<noiseIntensity>k__BackingField
	float ___U3CnoiseIntensityU3Ek__BackingField_11;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs
struct ARCameraFrameEventArgs_t4060608C37C2B7248AFC908876309CC36D53E0EC_marshaled_pinvoke
{
	ARLightEstimationData_tE622C47E05EBA84E05326E72C9D258F0200D5CE7_marshaled_pinvoke ___U3ClightEstimationU3Ek__BackingField_0;
	Nullable_1_t365991B3904FDA7642A788423B28692FDC7CDB17 ___U3CtimestampNsU3Ek__BackingField_1;
	Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA ___U3CprojectionMatrixU3Ek__BackingField_2;
	Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA ___U3CdisplayMatrixU3Ek__BackingField_3;
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___U3CtexturesU3Ek__BackingField_4;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3CpropertyNameIdsU3Ek__BackingField_5;
	Nullable_1_t6E154519A812D040E3016229CD7638843A2CC165 ___U3CexposureDurationU3Ek__BackingField_6;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CexposureOffsetU3Ek__BackingField_7;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CenabledMaterialKeywordsU3Ek__BackingField_8;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CdisabledMaterialKeywordsU3Ek__BackingField_9;
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___U3CcameraGrainTextureU3Ek__BackingField_10;
	float ___U3CnoiseIntensityU3Ek__BackingField_11;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARCameraFrameEventArgs
struct ARCameraFrameEventArgs_t4060608C37C2B7248AFC908876309CC36D53E0EC_marshaled_com
{
	ARLightEstimationData_tE622C47E05EBA84E05326E72C9D258F0200D5CE7_marshaled_com ___U3ClightEstimationU3Ek__BackingField_0;
	Nullable_1_t365991B3904FDA7642A788423B28692FDC7CDB17 ___U3CtimestampNsU3Ek__BackingField_1;
	Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA ___U3CprojectionMatrixU3Ek__BackingField_2;
	Nullable_1_t4DE2D2A1D2B73B95E813201AC08E1041435836AA ___U3CdisplayMatrixU3Ek__BackingField_3;
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___U3CtexturesU3Ek__BackingField_4;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3CpropertyNameIdsU3Ek__BackingField_5;
	Nullable_1_t6E154519A812D040E3016229CD7638843A2CC165 ___U3CexposureDurationU3Ek__BackingField_6;
	Nullable_1_t3D746CBB6123D4569FF4DEA60BC4240F32C6FE75 ___U3CexposureOffsetU3Ek__BackingField_7;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CenabledMaterialKeywordsU3Ek__BackingField_8;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ___U3CdisabledMaterialKeywordsU3Ek__BackingField_9;
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___U3CcameraGrainTextureU3Ek__BackingField_10;
	float ___U3CnoiseIntensityU3Ek__BackingField_11;
};

// UnityEngine.XR.ARFoundation.ARRaycastHit
struct ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 
{
	// System.Single UnityEngine.XR.ARFoundation.ARRaycastHit::<distance>k__BackingField
	float ___U3CdistanceU3Ek__BackingField_0;
	// UnityEngine.XR.ARFoundation.ARTrackable UnityEngine.XR.ARFoundation.ARRaycastHit::<trackable>k__BackingField
	ARTrackable_t1D98417758C08E98A333CDEC0C2C1688CE10B2E0* ___U3CtrackableU3Ek__BackingField_1;
	// UnityEngine.XR.ARSubsystems.XRRaycastHit UnityEngine.XR.ARFoundation.ARRaycastHit::m_Hit
	XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 ___m_Hit_2;
	// UnityEngine.Transform UnityEngine.XR.ARFoundation.ARRaycastHit::m_Transform
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___m_Transform_3;
};
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARFoundation.ARRaycastHit
struct ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70_marshaled_pinvoke
{
	float ___U3CdistanceU3Ek__BackingField_0;
	ARTrackable_t1D98417758C08E98A333CDEC0C2C1688CE10B2E0* ___U3CtrackableU3Ek__BackingField_1;
	XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 ___m_Hit_2;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___m_Transform_3;
};
// Native definition for COM marshalling of UnityEngine.XR.ARFoundation.ARRaycastHit
struct ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70_marshaled_com
{
	float ___U3CdistanceU3Ek__BackingField_0;
	ARTrackable_t1D98417758C08E98A333CDEC0C2C1688CE10B2E0* ___U3CtrackableU3Ek__BackingField_1;
	XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 ___m_Hit_2;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___m_Transform_3;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif



static  KeyValuePair_2_t8E0D15B87910CDDA42560D1A46FD995D80D1210F UnresolvedVirtualCall_0 (RuntimeObject* __this, const RuntimeMethod* method)
{
	KeyValuePair_2_t8E0D15B87910CDDA42560D1A46FD995D80D1210F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  KeyValuePair_2_tA15A2CDE2D0067F592CD9373418E53A418842273 UnresolvedVirtualCall_1 (RuntimeObject* __this, const RuntimeMethod* method)
{
	KeyValuePair_2_tA15A2CDE2D0067F592CD9373418E53A418842273 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  KeyValuePair_2_tFA55EACE445F07ED0E758AB6E024B85AB8FD089D UnresolvedVirtualCall_2 (RuntimeObject* __this, const RuntimeMethod* method)
{
	KeyValuePair_2_tFA55EACE445F07ED0E758AB6E024B85AB8FD089D il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  KeyValuePair_2_tFC32D2507216293851350D29B64D79F950B55230 UnresolvedVirtualCall_3 (RuntimeObject* __this, const RuntimeMethod* method)
{
	KeyValuePair_2_tFC32D2507216293851350D29B64D79F950B55230 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF UnresolvedVirtualCall_4 (RuntimeObject* __this, const RuntimeMethod* method)
{
	NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t280B4C6187922FE73AC16AC7F23255AE192676E2 UnresolvedVirtualCall_5 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	NativeArray_1_t280B4C6187922FE73AC16AC7F23255AE192676E2 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_tAE1C2CA4717E405609ED9F96E485A9FE00E622D6 UnresolvedVirtualCall_6 (RuntimeObject* __this, XRCameraConfiguration_t36D3B10519762ADD407F4A4F171D120CE2B3BD63 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	NativeArray_1_tAE1C2CA4717E405609ED9F96E485A9FE00E622D6 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t4998E9C3FBA8DDD4E076225A6D136D48D0C25386 UnresolvedVirtualCall_7 (RuntimeObject* __this, XRHumanBodyPose2DJoint_t9674B917C7629002A302E572CABC8ACED71EFF26 p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5};
	NativeArray_1_t4998E9C3FBA8DDD4E076225A6D136D48D0C25386 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedVirtualCall_8 (RuntimeObject* __this, const RuntimeMethod* method)
{
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedVirtualCall_9 (RuntimeObject* __this, Ray_t2B1742D7958DC05BDC3EFC7461D3593E1430DC00 p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedStaticCall_9 (Ray_t2B1742D7958DC05BDC3EFC7461D3593E1430DC00 p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedVirtualCall_10 (RuntimeObject* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedStaticCall_10 (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedVirtualCall_11 (RuntimeObject* __this, XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 p1, Ray_t2B1742D7958DC05BDC3EFC7461D3593E1430DC00 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4};
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 UnresolvedVirtualCall_12 (RuntimeObject* __this, XRRaycastHit_t87A29A58C1D41AF1B3995B73777A7494B0695780 p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4};
	NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  NativeArray_1_t6C2613A1D4A03EFEE59BBADBC529386D1205D01C UnresolvedVirtualCall_13 (RuntimeObject* __this, XRTextureDescriptor_t699023EDE6E2593F61CE969A68B5E56CD04CFA19 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	NativeArray_1_t6C2613A1D4A03EFEE59BBADBC529386D1205D01C il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  Nullable_1_tCF32C56A2641879C053C86F273C0C6EC1B40BC28 UnresolvedVirtualCall_14 (RuntimeObject* __this, const RuntimeMethod* method)
{
	Nullable_1_tCF32C56A2641879C053C86F273C0C6EC1B40BC28 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  Nullable_1_t4F11BA1306120798159EC97ABA03E6731032A09F UnresolvedVirtualCall_15 (RuntimeObject* __this, const RuntimeMethod* method)
{
	Nullable_1_t4F11BA1306120798159EC97ABA03E6731032A09F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  ReadOnlySpan_1_tA850A6C0E88ABBA37646A078ACBC24D6D5FD9B4D UnresolvedVirtualCall_16 (RuntimeObject* __this, const RuntimeMethod* method)
{
	ReadOnlySpan_1_tA850A6C0E88ABBA37646A078ACBC24D6D5FD9B4D il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_tFC79B2E1FF9EFB1D5754F6995583D33A519F300F UnresolvedVirtualCall_17 (RuntimeObject* __this, BoundedPlane_tF51C315A8961EB42F0A1B60D47158646E5AF75CE p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_tFC79B2E1FF9EFB1D5754F6995583D33A519F300F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_tFC79B2E1FF9EFB1D5754F6995583D33A519F300F UnresolvedVirtualCall_18 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_tFC79B2E1FF9EFB1D5754F6995583D33A519F300F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t6971CD7F709E7353F4365FE06A109B21A0F0C931 UnresolvedVirtualCall_19 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t6971CD7F709E7353F4365FE06A109B21A0F0C931 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t6971CD7F709E7353F4365FE06A109B21A0F0C931 UnresolvedVirtualCall_20 (RuntimeObject* __this, XRAnchor_tDD427E66CAA09DE7B058EA76223EF7DC3880FE82 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t6971CD7F709E7353F4365FE06A109B21A0F0C931 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t03BF8B384A61E7421A4748384189C50C3A2C323F UnresolvedVirtualCall_21 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t03BF8B384A61E7421A4748384189C50C3A2C323F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t03BF8B384A61E7421A4748384189C50C3A2C323F UnresolvedVirtualCall_22 (RuntimeObject* __this, XREnvironmentProbe_tAA657FAB648E2599B519F9FD66A1CEED65034DD9 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t03BF8B384A61E7421A4748384189C50C3A2C323F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t244050823CF4D8F3C9DFAE4AB0CEFA639C719119 UnresolvedVirtualCall_23 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t244050823CF4D8F3C9DFAE4AB0CEFA639C719119 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t244050823CF4D8F3C9DFAE4AB0CEFA639C719119 UnresolvedVirtualCall_24 (RuntimeObject* __this, XRFace_t235F951F4AC7CC6A0CA6829CECA05210D64982FB p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t244050823CF4D8F3C9DFAE4AB0CEFA639C719119 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_tAB0D56187755251BCF253FBC179ABFC1B18E00C6 UnresolvedVirtualCall_25 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_tAB0D56187755251BCF253FBC179ABFC1B18E00C6 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_tAB0D56187755251BCF253FBC179ABFC1B18E00C6 UnresolvedVirtualCall_26 (RuntimeObject* __this, XRHumanBody_t88EF91F599A4F22EABB233F85DE7782EE8B86692 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_tAB0D56187755251BCF253FBC179ABFC1B18E00C6 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t2CDAB668CF6C2AB6D755F9C2911626A1C9140179 UnresolvedVirtualCall_27 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t2CDAB668CF6C2AB6D755F9C2911626A1C9140179 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t2CDAB668CF6C2AB6D755F9C2911626A1C9140179 UnresolvedVirtualCall_28 (RuntimeObject* __this, XRParticipant_t3885B841862D28B0509433D566F00FA3C3CD79E1 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t2CDAB668CF6C2AB6D755F9C2911626A1C9140179 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t33787F6E969DAC65E8C2FD57FE6AAC9119CFDB89 UnresolvedVirtualCall_29 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t33787F6E969DAC65E8C2FD57FE6AAC9119CFDB89 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t33787F6E969DAC65E8C2FD57FE6AAC9119CFDB89 UnresolvedVirtualCall_30 (RuntimeObject* __this, XRPointCloud_t99DB921A9C92F53CEA3EB29A64E2DECDA6EA7D8C p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t33787F6E969DAC65E8C2FD57FE6AAC9119CFDB89 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t097463074AB33F65828FED3152F6A605C0B114A5 UnresolvedVirtualCall_31 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t097463074AB33F65828FED3152F6A605C0B114A5 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t097463074AB33F65828FED3152F6A605C0B114A5 UnresolvedVirtualCall_32 (RuntimeObject* __this, XRRaycast_t100015712885CDF4EF42820EB36277DC6DDC8103 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t097463074AB33F65828FED3152F6A605C0B114A5 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t570BA80B84560BB489FE51A45629812BC8E0B02F UnresolvedVirtualCall_33 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t570BA80B84560BB489FE51A45629812BC8E0B02F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t570BA80B84560BB489FE51A45629812BC8E0B02F UnresolvedVirtualCall_34 (RuntimeObject* __this, XRReferencePoint_t7B269D148483373FDE78B3262CF334C2D86B6291 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t570BA80B84560BB489FE51A45629812BC8E0B02F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t5289D1DB76FBCB9C1A7B387927387F4299599C1E UnresolvedVirtualCall_35 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_t5289D1DB76FBCB9C1A7B387927387F4299599C1E il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_t5289D1DB76FBCB9C1A7B387927387F4299599C1E UnresolvedVirtualCall_36 (RuntimeObject* __this, XRTrackedImage_t0F99DAB96B2D6422D0F8DA720F9BEFD3655DDFDD p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_t5289D1DB76FBCB9C1A7B387927387F4299599C1E il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_tBC4635C00390DED792828CD9C45501D0F38AFEE6 UnresolvedVirtualCall_37 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TrackableChanges_1_tBC4635C00390DED792828CD9C45501D0F38AFEE6 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TrackableChanges_1_tBC4635C00390DED792828CD9C45501D0F38AFEE6 UnresolvedVirtualCall_38 (RuntimeObject* __this, XRTrackedObject_t56B5A101A8698B5C95F2CBE93FCF0F8911B67E75 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	TrackableChanges_1_tBC4635C00390DED792828CD9C45501D0F38AFEE6 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 UnresolvedVirtualCall_39 (RuntimeObject* __this, const RuntimeMethod* method)
{
	ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 UnresolvedVirtualCall_40 (RuntimeObject* __this, const RuntimeMethod* method)
{
	ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  AddReferenceImageJobState_tCF90A84092F3D2A7536D1D28C9E6EC0D7F53937A UnresolvedVirtualCall_41 (RuntimeObject* __this, NativeSlice_1_tCEC4B2B900638EC1820BB61FE436766204DFD8DA p1, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A p2, int32_t p3, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p4, JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5};
	AddReferenceImageJobState_tCF90A84092F3D2A7536D1D28C9E6EC0D7F53937A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_42 (RuntimeObject* __this, const RuntimeMethod* method)
{
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedInstanceCall_42 (void* __this, const RuntimeMethod* method)
{
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_42 (const RuntimeMethod* method)
{
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_43 (RuntimeObject* __this, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_43 (NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_44 (RuntimeObject* __this, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p1, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_45 (RuntimeObject* __this, Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p1, RuntimeObject* p2, ReadOnlySpan_1_t59614EA6E51A945A32B02AB17FBCBDF9A5C419C1 p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,&p3,p4};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_46 (RuntimeObject* __this, ValueTuple_2_tC3717D4552EE1E5FC27BFBA3F5155741BC04557A p1, ValueTuple_2_tC3717D4552EE1E5FC27BFBA3F5155741BC04557A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_47 (RuntimeObject* __this, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_47 (ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_48 (RuntimeObject* __this, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p1, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_49 (RuntimeObject* __this, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_49 (ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_50 (RuntimeObject* __this, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p1, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_51 (RuntimeObject* __this, uint8_t p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_52 (RuntimeObject* __this, CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_53 (RuntimeObject* __this, CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_54 (RuntimeObject* __this, Guid_t p1, Guid_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_55 (RuntimeObject* __this, Guid_t p1, RuntimeObject* p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,&p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_56 (RuntimeObject* __this, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_56 (InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_57 (RuntimeObject* __this, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_58 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_58 (int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_59 (RuntimeObject* __this, int32_t p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_60 (RuntimeObject* __this, int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_61 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_62 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_63 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, int32_t p8, RuntimeObject* p9, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5,&p6,&p7,&p8,p9};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_64 (RuntimeObject* __this, int32_t p1, int32_t p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_65 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_66 (RuntimeObject* __this, int32_t p1, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A p2, int32_t p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,p4};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_67 (RuntimeObject* __this, int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, intptr_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_68 (RuntimeObject* __this, intptr_t p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_69 (RuntimeObject* __this, MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_70 (RuntimeObject* __this, MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC p1, MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_71 (RuntimeObject* __this, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_71 (MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_72 (RuntimeObject* __this, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p1, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_73 (RuntimeObject* __this, MeshTransform_t669BDD0278EB7AC2976F16FD341CC1C4747FAA6A p1, MeshTransform_t669BDD0278EB7AC2976F16FD341CC1C4747FAA6A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_74 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedInstanceCall_74 (void* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_74 (RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_75 (RuntimeObject* p1, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_76 (RuntimeObject* p1, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_77 (RuntimeObject* p1, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_78 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_79 (RuntimeObject* p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_80 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_80 (RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_81 (RuntimeObject* p1, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_82 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_82 (RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_83 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_84 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_84 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_85 (RuntimeObject* p1, uint64_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_86 (RuntimeObject* p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_87 (RuntimeObject* p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_88 (RuntimeObject* p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_89 (RuntimeObject* p1, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_90 (RuntimeObject* p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_91 (RuntimeObject* p1, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_92 (RuntimeObject* p1, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_93 (RuntimeObject* p1, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_94 (RuntimeObject* p1, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_95 (RuntimeObject* p1, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_96 (RuntimeObject* __this, Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_97 (RuntimeObject* __this, Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,p4};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_98 (RuntimeObject* __this, Ray_t2B1742D7958DC05BDC3EFC7461D3593E1430DC00 p1, float p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_99 (RuntimeObject* __this, ResourceLocator_t84F68A0DD2AA185761938E49BBE9B2C46A47E122 p1, ResourceLocator_t84F68A0DD2AA185761938E49BBE9B2C46A47E122 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_100 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_101 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, Pose_t06BA69EAA6E9FAF60056D519A87D25F54AFE7971 p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_102 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_103 (RuntimeObject* __this, uint16_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_103 (uint16_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_104 (RuntimeObject* __this, uint16_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_105 (RuntimeObject* __this, uint16_t p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_106 (RuntimeObject* __this, uint16_t p1, uint16_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_107 (RuntimeObject* __this, uint64_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_107 (uint64_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_108 (RuntimeObject* __this, uint64_t p1, uint64_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_109 (RuntimeObject* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_109 (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_110 (RuntimeObject* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, float p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_111 (RuntimeObject* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_112 (RuntimeObject* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_112 (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_113 (RuntimeObject* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_114 (RuntimeObject* __this, XRCameraParams_t2EBCCDA7FA502A7BDA940461C44C7817E5B44B40 p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_115 (RuntimeObject* __this, XRCpuImage_t36F512AD65D5B0AA1CC458C3666873D741C60A57 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_116 (RuntimeObject* __this, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_116 (XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_117 (RuntimeObject* __this, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_118 (RuntimeObject* __this, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_118 (XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_119 (RuntimeObject* __this, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p1, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_120 (RuntimeObject* __this, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_120 (XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_121 (RuntimeObject* __this, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_122 (RuntimeObject* __this, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_122 (OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_123 (RuntimeObject* __this, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p1, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_124 (RuntimeObject* __this, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_124 (RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_125 (RuntimeObject* __this, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p1, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_126 (RuntimeObject* __this, CachedCodeEntryKey_t8A54BDD6E52145D17DB1A2EB0CE0B4D4CB112F31 p1, CachedCodeEntryKey_t8A54BDD6E52145D17DB1A2EB0CE0B4D4CB112F31 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_127 (RuntimeObject* __this, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_127 (SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_128 (RuntimeObject* __this, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p1, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_129 (RuntimeObject* __this, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_129 (PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_130 (RuntimeObject* __this, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p1, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_131 (RuntimeObject* __this, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedStaticCall_131 (WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint8_t UnresolvedVirtualCall_132 (RuntimeObject* __this, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p1, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	uint8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  Configuration_tF3E68F5793D5A997146A65AEAAC9B062BCAF0947 UnresolvedVirtualCall_133 (RuntimeObject* __this, NativeSlice_1_t398BDCDCE5F9AF840285A8E6EC69152FED8FADFE p1, uint64_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	Configuration_tF3E68F5793D5A997146A65AEAAC9B062BCAF0947 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  ConsoleKeyInfo_t84640C60F53D0F6946B147ADAAF0366BBF1DE900 UnresolvedVirtualCall_134 (RuntimeObject* __this, uint8_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	ConsoleKeyInfo_t84640C60F53D0F6946B147ADAAF0366BBF1DE900 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02 UnresolvedVirtualCall_135 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F UnresolvedVirtualCall_136 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D UnresolvedVirtualCall_137 (RuntimeObject* __this, const RuntimeMethod* method)
{
	DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D UnresolvedVirtualCall_138 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, int32_t p8, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5,&p6,&p7,&p8};
	DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D UnresolvedVirtualCall_139 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F UnresolvedVirtualCall_140 (RuntimeObject* __this, const RuntimeMethod* method)
{
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F UnresolvedVirtualCall_141 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	Decimal_tDA6C877282B2D789CF97C0949661CC11D643969F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  DictionaryEntry_t171080F37B311C25AA9E75888F9C9D703FA721BB UnresolvedVirtualCall_142 (RuntimeObject* __this, const RuntimeMethod* method)
{
	DictionaryEntry_t171080F37B311C25AA9E75888F9C9D703FA721BB il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  double UnresolvedVirtualCall_143 (RuntimeObject* __this, const RuntimeMethod* method)
{
	double il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  double UnresolvedVirtualCall_144 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	double il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  Guid_t UnresolvedVirtualCall_145 (RuntimeObject* __this, const RuntimeMethod* method)
{
	Guid_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  Guid_t UnresolvedStaticCall_145 (const RuntimeMethod* method)
{
	Guid_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD UnresolvedVirtualCall_146 (RuntimeObject* __this, const RuntimeMethod* method)
{
	InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int16_t UnresolvedVirtualCall_147 (RuntimeObject* __this, const RuntimeMethod* method)
{
	int16_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int16_t UnresolvedVirtualCall_148 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	int16_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_149 (RuntimeObject* __this, const RuntimeMethod* method)
{
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedInstanceCall_149 (void* __this, const RuntimeMethod* method)
{
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_149 (const RuntimeMethod* method)
{
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_150 (RuntimeObject* __this, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_151 (RuntimeObject* __this, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p1, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_151 (NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p1, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_152 (RuntimeObject* __this, ReadOnlySpan_1_tA850A6C0E88ABBA37646A078ACBC24D6D5FD9B4D p1, Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_153 (RuntimeObject* __this, ReadOnlySpan_1_t59614EA6E51A945A32B02AB17FBCBDF9A5C419C1 p1, Span_1_tDADAC65069DFE6B57C458109115ECD795ED39305 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_154 (RuntimeObject* __this, Span_1_tDADAC65069DFE6B57C458109115ECD795ED39305 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_155 (RuntimeObject* __this, ValueTuple_2_tC3717D4552EE1E5FC27BFBA3F5155741BC04557A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_156 (RuntimeObject* __this, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_157 (RuntimeObject* __this, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p1, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_157 (ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p1, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_158 (RuntimeObject* __this, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_159 (RuntimeObject* __this, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p1, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_159 (ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p1, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_160 (RuntimeObject* __this, AddReferenceImageJobState_tCF90A84092F3D2A7536D1D28C9E6EC0D7F53937A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_161 (RuntimeObject* __this, uint8_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_162 (RuntimeObject* __this, uint8_t p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_163 (RuntimeObject* __this, CustomAttributeNamedArgument_t4EC1C2BB9943BEB7E77AC0870BE2A899E23B4E02 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_164 (RuntimeObject* __this, CustomAttributeTypedArgument_tAAA19ADE66B16A67D030C8C67D7ADB29A7BEC75F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_165 (RuntimeObject* __this, DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_166 (RuntimeObject* __this, DateTime_t66193957C73913903DDAD89FEDC46139BCA5802D p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_167 (RuntimeObject* __this, Guid_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_168 (RuntimeObject* __this, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_169 (RuntimeObject* __this, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_169 (InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_170 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_171 (RuntimeObject* __this, int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedInstanceCall_171 (void* __this, int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_171 (int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_172 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_173 (RuntimeObject* __this, int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_174 (RuntimeObject* __this, int64_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_175 (RuntimeObject* __this, intptr_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_176 (RuntimeObject* __this, intptr_t p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_177 (RuntimeObject* __this, MeshId_t2CF122567F06D0AA4F80DDA5CB51E8CD3B7EA2AC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_178 (RuntimeObject* __this, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_179 (RuntimeObject* __this, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p1, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_179 (MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p1, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_180 (RuntimeObject* __this, MeshTransform_t669BDD0278EB7AC2976F16FD341CC1C4747FAA6A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_181 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedInstanceCall_181 (void* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_181 (RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_182 (RuntimeObject* p1, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p2, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_183 (RuntimeObject* __this, RuntimeObject* p1, NativeArray_1_t1ABEAB84724CAEAFCB8767B8502FD3185AC9CAD0 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_184 (RuntimeObject* p1, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p2, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_185 (RuntimeObject* __this, RuntimeObject* p1, ARRaycastHit_tB32B5606815B8A7DF479C00187A852F8D20E3B70 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_186 (RuntimeObject* p1, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p2, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_187 (RuntimeObject* __this, RuntimeObject* p1, ARTextureInfo_t008DA41DF9555306803303A0353619E5C0917261 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_188 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_189 (RuntimeObject* p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_190 (RuntimeObject* __this, RuntimeObject* p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_191 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_192 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_193 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_193 (RuntimeObject* p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_194 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, uint8_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_195 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_196 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, RuntimeObject* p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,p4,&p5};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_197 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, RuntimeObject* p4, int32_t p5, uint8_t p6, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,p4,&p5,&p6};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_198 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, RuntimeObject* p4, int32_t p5, int32_t p6, int32_t p7, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,p4,&p5,&p6,&p7};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_199 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_200 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_201 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, int32_t p4, uint8_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,&p4,&p5};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_202 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, int32_t p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,&p4,p5};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_203 (RuntimeObject* __this, RuntimeObject* p1, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_204 (RuntimeObject* p1, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p2, MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_205 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_205 (RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_206 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_207 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_207 (RuntimeObject* p1, RuntimeObject* p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_208 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4,&p5};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_209 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_210 (RuntimeObject* p1, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p2, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_211 (RuntimeObject* __this, RuntimeObject* p1, uint64_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_212 (RuntimeObject* p1, uint64_t p2, uint64_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_213 (RuntimeObject* __this, RuntimeObject* p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_214 (RuntimeObject* p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_215 (RuntimeObject* __this, RuntimeObject* p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_216 (RuntimeObject* p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_217 (RuntimeObject* __this, RuntimeObject* p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_218 (RuntimeObject* p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_219 (RuntimeObject* __this, RuntimeObject* p1, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_220 (RuntimeObject* p1, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p2, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_221 (RuntimeObject* __this, RuntimeObject* p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_222 (RuntimeObject* p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_223 (RuntimeObject* __this, RuntimeObject* p1, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_224 (RuntimeObject* p1, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p2, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_225 (RuntimeObject* __this, RuntimeObject* p1, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_226 (RuntimeObject* p1, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p2, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_227 (RuntimeObject* __this, RuntimeObject* p1, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_228 (RuntimeObject* p1, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p2, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_229 (RuntimeObject* __this, RuntimeObject* p1, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_230 (RuntimeObject* p1, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p2, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_231 (RuntimeObject* __this, RuntimeObject* p1, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_232 (RuntimeObject* p1, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p2, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_233 (RuntimeObject* __this, ResourceLocator_t84F68A0DD2AA185761938E49BBE9B2C46A47E122 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_234 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_235 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_235 (TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_236 (RuntimeObject* __this, uint64_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_237 (RuntimeObject* __this, uint64_t p1, uint64_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_237 (uint64_t p1, uint64_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_238 (RuntimeObject* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_239 (RuntimeObject* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_239 (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_240 (RuntimeObject* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_241 (RuntimeObject* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_241 (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_242 (RuntimeObject* __this, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_243 (RuntimeObject* __this, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_243 (XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_244 (RuntimeObject* __this, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_245 (RuntimeObject* __this, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p1, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_245 (XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p1, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_246 (RuntimeObject* __this, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_247 (RuntimeObject* __this, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_247 (XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_248 (RuntimeObject* __this, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_249 (RuntimeObject* __this, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p1, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_249 (OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p1, OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_250 (RuntimeObject* __this, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_251 (RuntimeObject* __this, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p1, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_251 (RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p1, RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_252 (RuntimeObject* __this, CachedCodeEntryKey_t8A54BDD6E52145D17DB1A2EB0CE0B4D4CB112F31 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_253 (RuntimeObject* __this, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_254 (RuntimeObject* __this, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p1, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_254 (SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p1, SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_255 (RuntimeObject* __this, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_256 (RuntimeObject* __this, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p1, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_256 (PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p1, PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_257 (RuntimeObject* __this, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedVirtualCall_258 (RuntimeObject* __this, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p1, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int32_t UnresolvedStaticCall_258 (WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p1, WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int64_t UnresolvedVirtualCall_259 (RuntimeObject* __this, const RuntimeMethod* method)
{
	int64_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int64_t UnresolvedVirtualCall_260 (RuntimeObject* __this, int64_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	int64_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int64_t UnresolvedVirtualCall_261 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	int64_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  int64_t UnresolvedVirtualCall_262 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	int64_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  intptr_t UnresolvedVirtualCall_263 (RuntimeObject* __this, const RuntimeMethod* method)
{
	intptr_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 UnresolvedVirtualCall_264 (RuntimeObject* __this, NativeSlice_1_tCEC4B2B900638EC1820BB61FE436766204DFD8DA p1, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A p2, int32_t p3, XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F p4, JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5};
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 UnresolvedVirtualCall_265 (RuntimeObject* __this, BatchCullingContext_t6133D8CF3B9A93AED429E017C62DC2F5BD64A659 p1, BatchCullingOutput_tF997DE602CE8F5E44654FD157113EF455DBE785F p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 UnresolvedInstanceCall_265 (void* __this, BatchCullingContext_t6133D8CF3B9A93AED429E017C62DC2F5BD64A659 p1, BatchCullingOutput_tF997DE602CE8F5E44654FD157113EF455DBE785F p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 UnresolvedVirtualCall_266 (RuntimeObject* __this, RuntimeObject* p1, BatchCullingContext_t6133D8CF3B9A93AED429E017C62DC2F5BD64A659 p2, BatchCullingOutput_tF997DE602CE8F5E44654FD157113EF455DBE785F p3, intptr_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 UnresolvedStaticCall_266 (RuntimeObject* p1, BatchCullingContext_t6133D8CF3B9A93AED429E017C62DC2F5BD64A659 p2, BatchCullingOutput_tF997DE602CE8F5E44654FD157113EF455DBE785F p3, intptr_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 UnresolvedStaticCall_267 (RuntimeObject* p1, RuntimeObject* p2, BatchCullingContext_t6133D8CF3B9A93AED429E017C62DC2F5BD64A659 p3, BatchCullingOutput_tF997DE602CE8F5E44654FD157113EF455DBE785F p4, intptr_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4,&p5};
	JobHandle_t5DF5F99902FED3C801A81C05205CEA6CE039EF08 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA UnresolvedVirtualCall_268 (RuntimeObject* __this, const RuntimeMethod* method)
{
	MeshInfo_t0BB7A8C2C586FD5EAD40E9E4E1749150915FDFFA il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_269 (RuntimeObject* __this, const RuntimeMethod* method)
{
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedInstanceCall_269 (void* __this, const RuntimeMethod* method)
{
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_269 (const RuntimeMethod* method)
{
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_270 (RuntimeObject* __this, KeyValuePair_2_tFC32D2507216293851350D29B64D79F950B55230 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_270 (KeyValuePair_2_tFC32D2507216293851350D29B64D79F950B55230 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_271 (RuntimeObject* __this, uint8_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_272 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_273 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, int32_t p3, RuntimeObject* p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,&p3,p4,p5};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_274 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_275 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3,p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_276 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3,p4,p5};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_277 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, RuntimeObject* p5, RuntimeObject* p6, RuntimeObject* p7, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3,p4,p5,p6,p7};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_278 (RuntimeObject* __this, int64_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_279 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedInstanceCall_279 (void* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_279 (RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_280 (RuntimeObject* p1, KeyValuePair_2_tFC32D2507216293851350D29B64D79F950B55230 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_281 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedInstanceCall_281 (void* __this, RuntimeObject* p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_282 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_283 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_283 (RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_284 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_285 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, RuntimeObject* p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,p4,p5};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_286 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, int32_t p4, RuntimeObject* p5, RuntimeObject* p6, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,&p4,p5,p6};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_287 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, RuntimeObject* p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,p4,p5};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_288 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, RuntimeObject* p4, RuntimeObject* p5, RuntimeObject* p6, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,p4,p5,p6};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_289 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, RuntimeObject* p3, RuntimeObject* p4, RuntimeObject* p5, RuntimeObject* p6, RuntimeObject* p7, RuntimeObject* p8, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3,p4,p5,p6,p7,p8};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_290 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedInstanceCall_290 (void* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_290 (RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_291 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_291 (RuntimeObject* p1, RuntimeObject* p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_292 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_292 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_293 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, uint8_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,&p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_294 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_294 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_295 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_296 (RuntimeObject* p1, Ray_t2B1742D7958DC05BDC3EFC7461D3593E1430DC00 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_297 (RuntimeObject* __this, RuntimeObject* p1, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_298 (RuntimeObject* p1, uint16_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedStaticCall_299 (RuntimeObject* p1, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeObject* UnresolvedVirtualCall_300 (RuntimeObject* __this, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	RuntimeObject* il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  Playable_t95C6B795846BA0C7D96E4DA14897CCCF2554334F UnresolvedVirtualCall_301 (RuntimeObject* __this, PlayableGraph_t4A5B0B45343A240F0761574FD7C672E0CFFF7A6E p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	Playable_t95C6B795846BA0C7D96E4DA14897CCCF2554334F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 UnresolvedStaticCall_302 (RuntimeObject* p1, PlayableGraph_t4A5B0B45343A240F0761574FD7C672E0CFFF7A6E p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3};
	PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 UnresolvedVirtualCall_303 (RuntimeObject* __this, PlayableGraph_t4A5B0B45343A240F0761574FD7C672E0CFFF7A6E p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 UnresolvedStaticCall_303 (PlayableGraph_t4A5B0B45343A240F0761574FD7C672E0CFFF7A6E p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	PlayableOutput_t2F7C45A58DA3E788EEDDB439549E21CF3FCF3680 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 UnresolvedVirtualCall_304 (RuntimeObject* __this, const RuntimeMethod* method)
{
	RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeMethodHandle_tB35B96E97214DCBE20B0B02B1E687884B34680B2 UnresolvedVirtualCall_305 (RuntimeObject* __this, const RuntimeMethod* method)
{
	RuntimeMethodHandle_tB35B96E97214DCBE20B0B02B1E687884B34680B2 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RuntimeTypeHandle_t332A452B8B6179E4469B69525D0FE82A88030F7B UnresolvedVirtualCall_306 (RuntimeObject* __this, const RuntimeMethod* method)
{
	RuntimeTypeHandle_t332A452B8B6179E4469B69525D0FE82A88030F7B il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int8_t UnresolvedVirtualCall_307 (RuntimeObject* __this, const RuntimeMethod* method)
{
	int8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  int8_t UnresolvedVirtualCall_308 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	int8_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  float UnresolvedVirtualCall_309 (RuntimeObject* __this, const RuntimeMethod* method)
{
	float il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  float UnresolvedVirtualCall_310 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	float il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A UnresolvedVirtualCall_311 (RuntimeObject* __this, const RuntimeMethod* method)
{
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A UnresolvedInstanceCall_311 (void* __this, const RuntimeMethod* method)
{
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A UnresolvedVirtualCall_312 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A UnresolvedStaticCall_312 (RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A UnresolvedStaticCall_313 (RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A UnresolvedVirtualCall_314 (RuntimeObject* __this, TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	TimeSpan_t8195C5B013A2C532FEBDF0B64B6911982E750F5A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint16_t UnresolvedVirtualCall_315 (RuntimeObject* __this, const RuntimeMethod* method)
{
	uint16_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint16_t UnresolvedVirtualCall_316 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	uint16_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint16_t UnresolvedVirtualCall_317 (RuntimeObject* __this, uint16_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	uint16_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint32_t UnresolvedVirtualCall_318 (RuntimeObject* __this, const RuntimeMethod* method)
{
	uint32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint32_t UnresolvedVirtualCall_319 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	uint32_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint64_t UnresolvedVirtualCall_320 (RuntimeObject* __this, const RuntimeMethod* method)
{
	uint64_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  uint64_t UnresolvedVirtualCall_321 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	uint64_t il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 UnresolvedVirtualCall_322 (RuntimeObject* __this, const RuntimeMethod* method)
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 UnresolvedVirtualCall_323 (RuntimeObject* __this, const RuntimeMethod* method)
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  void UnresolvedVirtualCall_324 (RuntimeObject* __this, const RuntimeMethod* method)
{
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, NULL);
}
static  void UnresolvedInstanceCall_324 (void* __this, const RuntimeMethod* method)
{
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, NULL, NULL);
}
static  void UnresolvedStaticCall_324 (const RuntimeMethod* method)
{
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, NULL, NULL);
}
static  void UnresolvedVirtualCall_325 (RuntimeObject* __this, NativeArray_1_tDF6A1978B5813BF4DAD7948E398009FFC9BEA38D p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_325 (void* __this, NativeArray_1_tDF6A1978B5813BF4DAD7948E398009FFC9BEA38D p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_326 (RuntimeObject* __this, Nullable_1_t4F11BA1306120798159EC97ABA03E6731032A09F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_327 (RuntimeObject* __this, ReadOnlySpan_1_tA850A6C0E88ABBA37646A078ACBC24D6D5FD9B4D p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_328 (RuntimeObject* __this, Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p1, ValueTuple_3_tFD2ADB3DA89E958885034AAFEF1ABDA8C814D987 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_328 (Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p1, ValueTuple_3_tFD2ADB3DA89E958885034AAFEF1ABDA8C814D987 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_329 (RuntimeObject* __this, Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p1, ValueTuple_5_t558B9F95CA55DE5694FC58A3BEAE441BF728FB57 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_329 (Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p1, ValueTuple_5_t558B9F95CA55DE5694FC58A3BEAE441BF728FB57 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_330 (RuntimeObject* __this, ARAnchorsChangedEventArgs_t755E6208C84304CAC448C133B0A8660CD5750A75 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_330 (ARAnchorsChangedEventArgs_t755E6208C84304CAC448C133B0A8660CD5750A75 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_331 (RuntimeObject* __this, ARCameraFrameEventArgs_t4060608C37C2B7248AFC908876309CC36D53E0EC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_331 (ARCameraFrameEventArgs_t4060608C37C2B7248AFC908876309CC36D53E0EC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_332 (RuntimeObject* __this, ARCoreBeforeGetCameraConfigurationEventArgs_t9368C5A015241C02E50D864D77FDFC2D223FA451 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_332 (ARCoreBeforeGetCameraConfigurationEventArgs_t9368C5A015241C02E50D864D77FDFC2D223FA451 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_333 (RuntimeObject* __this, ARCoreBeforeSetConfigurationEventArgs_tF91B773E2C89D6954A1C4332EDC8FA09A5E22938 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_333 (ARCoreBeforeSetConfigurationEventArgs_tF91B773E2C89D6954A1C4332EDC8FA09A5E22938 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_334 (RuntimeObject* __this, AREnvironmentProbesChangedEvent_t8757E98E11F3D37F0CFC4589FCA5CD2107F8375C p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_334 (AREnvironmentProbesChangedEvent_t8757E98E11F3D37F0CFC4589FCA5CD2107F8375C p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_335 (RuntimeObject* __this, ARFaceUpdatedEventArgs_tC20D17255858678A1A8230EA32D7C38287221FF6 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_335 (ARFaceUpdatedEventArgs_tC20D17255858678A1A8230EA32D7C38287221FF6 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_336 (RuntimeObject* __this, ARFacesChangedEventArgs_tC05D4423CB2096FF5955C3A0A00056EE2B6301AE p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_336 (ARFacesChangedEventArgs_tC05D4423CB2096FF5955C3A0A00056EE2B6301AE p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_337 (RuntimeObject* __this, ARHumanBodiesChangedEventArgs_t19088E0D3384A22C5D8A542957705222C834720B p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_337 (ARHumanBodiesChangedEventArgs_t19088E0D3384A22C5D8A542957705222C834720B p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_338 (RuntimeObject* __this, ARMeshesChangedEventArgs_tE7A52D1E319626788F0990029A19823C3FA83903 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_338 (ARMeshesChangedEventArgs_tE7A52D1E319626788F0990029A19823C3FA83903 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_339 (RuntimeObject* __this, AROcclusionFrameEventArgs_t50615B48D249629849B4157545F18620A4304E81 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_339 (AROcclusionFrameEventArgs_t50615B48D249629849B4157545F18620A4304E81 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_340 (RuntimeObject* __this, ARParticipantsChangedEventArgs_t2EAD9041A074A7ACEFF280662784747A4E85E527 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_340 (ARParticipantsChangedEventArgs_t2EAD9041A074A7ACEFF280662784747A4E85E527 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_341 (RuntimeObject* __this, ARPlaneBoundaryChangedEventArgs_tE59EDE94575C8947AD3F1F8DA1370D0A426A5FFC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_341 (ARPlaneBoundaryChangedEventArgs_tE59EDE94575C8947AD3F1F8DA1370D0A426A5FFC p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_342 (RuntimeObject* __this, ARPlanesChangedEventArgs_t8D63E0257BF9942EF8F8C0445F2FD46421017872 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_342 (ARPlanesChangedEventArgs_t8D63E0257BF9942EF8F8C0445F2FD46421017872 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_343 (RuntimeObject* __this, ARPointCloudChangedEventArgs_t7DE4CA4D30D369496221061F89CC4BF84E42CC1B p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_343 (ARPointCloudChangedEventArgs_t7DE4CA4D30D369496221061F89CC4BF84E42CC1B p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_344 (RuntimeObject* __this, ARPointCloudUpdatedEventArgs_t9AC3E8FAC2452088DE276694AFE257D823EB79B4 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_344 (ARPointCloudUpdatedEventArgs_t9AC3E8FAC2452088DE276694AFE257D823EB79B4 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_345 (RuntimeObject* __this, ARRaycastUpdatedEventArgs_t4F200C75C97D91C3B96D3E6018CD31B9E9E19D6B p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_345 (ARRaycastUpdatedEventArgs_t4F200C75C97D91C3B96D3E6018CD31B9E9E19D6B p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_346 (RuntimeObject* __this, ARReferencePointsChangedEventArgs_t25F5471C71BDC45AB77834E2F331931EE37F7B62 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_346 (ARReferencePointsChangedEventArgs_t25F5471C71BDC45AB77834E2F331931EE37F7B62 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_347 (RuntimeObject* __this, ARSessionStateChangedEventArgs_tC31BD123D6B4F6168FB246762E79AB33962AE822 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_347 (ARSessionStateChangedEventArgs_tC31BD123D6B4F6168FB246762E79AB33962AE822 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_348 (RuntimeObject* __this, ARTrackablesParentTransformChangedEventArgs_tEF673BCB9382697300AE683ED29F0BF96E4A9C8A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_348 (ARTrackablesParentTransformChangedEventArgs_tEF673BCB9382697300AE683ED29F0BF96E4A9C8A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_349 (RuntimeObject* __this, ARTrackedImagesChangedEventArgs_tD7718E40EE25D22E9143DA4F556C44980E18BE2F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_349 (ARTrackedImagesChangedEventArgs_tD7718E40EE25D22E9143DA4F556C44980E18BE2F p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_350 (RuntimeObject* __this, ARTrackedObjectsChangedEventArgs_t378A63B91AD22EA4BA9C68805C72DDA4B7C01509 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_350 (ARTrackedObjectsChangedEventArgs_t378A63B91AD22EA4BA9C68805C72DDA4B7C01509 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_351 (RuntimeObject* __this, ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF p1, ArConfig_tC991F7E3046E638B111BDBE5A2B25C4F363C4F1C p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_351 (ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF p1, ArConfig_tC991F7E3046E638B111BDBE5A2B25C4F363C4F1C p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_352 (RuntimeObject* __this, uint8_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_352 (void* __this, uint8_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_352 (uint8_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_353 (RuntimeObject* __this, uint8_t p1, DebugScreenCapture_t859E4E87C94587A08893C726D4FF84BD8F288CC5 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_353 (void* __this, uint8_t p1, DebugScreenCapture_t859E4E87C94587A08893C726D4FF84BD8F288CC5 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_354 (RuntimeObject* __this, uint8_t p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_354 (uint8_t p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_355 (RuntimeObject* __this, CullingGroupEvent_tC79BA328A8280C29F6002F591614081A0E87D110 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_355 (CullingGroupEvent_tC79BA328A8280C29F6002F591614081A0E87D110 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_356 (RuntimeObject* __this, double p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_357 (RuntimeObject* __this, Guid_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_358 (RuntimeObject* __this, Guid_t p1, RuntimeObject* p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_359 (RuntimeObject* __this, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_359 (InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_360 (RuntimeObject* __this, int16_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_361 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_361 (void* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_361 (int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_362 (RuntimeObject* __this, int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_362 (void* __this, int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_362 (int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_363 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_364 (RuntimeObject* __this, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_365 (RuntimeObject* __this, int32_t p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_365 (int32_t p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_366 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_366 (int32_t p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_367 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_368 (RuntimeObject* __this, int32_t p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3,p4};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_369 (RuntimeObject* __this, int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_369 (int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_370 (RuntimeObject* __this, int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, intptr_t p3, int32_t p4, intptr_t p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_370 (int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, intptr_t p3, int32_t p4, intptr_t p5, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3,&p4,&p5};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_371 (RuntimeObject* __this, int32_t p1, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p2, RuntimeObject* p3, intptr_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3,&p4};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_372 (RuntimeObject* __this, int64_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_373 (RuntimeObject* __this, int64_t p1, RuntimeObject* p2, int64_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_374 (RuntimeObject* __this, intptr_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_374 (void* __this, intptr_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_374 (intptr_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_375 (RuntimeObject* __this, intptr_t p1, ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF p2, ArCameraConfigFilter_tF665AEAE3CDEB76E6485508096A093A9E0E0B607 p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_375 (intptr_t p1, ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF p2, ArCameraConfigFilter_tF665AEAE3CDEB76E6485508096A093A9E0E0B607 p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_376 (RuntimeObject* __this, intptr_t p1, intptr_t p2, RuntimeObject* p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3,&p4};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_376 (void* __this, intptr_t p1, intptr_t p2, RuntimeObject* p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_377 (RuntimeObject* __this, MeshGenerationResult_tD5A6D639B2CF1A3F855AFB41861DEC48DC0D3A9C p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_377 (MeshGenerationResult_tD5A6D639B2CF1A3F855AFB41861DEC48DC0D3A9C p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_378 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_378 (void* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_378 (RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_379 (RuntimeObject* __this, RuntimeObject* p1, NativeArray_1_tDF6A1978B5813BF4DAD7948E398009FFC9BEA38D p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_379 (RuntimeObject* p1, NativeArray_1_tDF6A1978B5813BF4DAD7948E398009FFC9BEA38D p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_380 (RuntimeObject* p1, Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p2, ValueTuple_3_tFD2ADB3DA89E958885034AAFEF1ABDA8C814D987 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_381 (RuntimeObject* p1, Span_1_tEDDF15FCF9EC6DEBA0F696BAACDDBAB9D92C252D p2, ValueTuple_5_t558B9F95CA55DE5694FC58A3BEAE441BF728FB57 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_382 (RuntimeObject* p1, ARAnchorsChangedEventArgs_t755E6208C84304CAC448C133B0A8660CD5750A75 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_383 (RuntimeObject* p1, ARCameraFrameEventArgs_t4060608C37C2B7248AFC908876309CC36D53E0EC p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_384 (RuntimeObject* p1, ARCoreBeforeGetCameraConfigurationEventArgs_t9368C5A015241C02E50D864D77FDFC2D223FA451 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_385 (RuntimeObject* p1, ARCoreBeforeSetConfigurationEventArgs_tF91B773E2C89D6954A1C4332EDC8FA09A5E22938 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_386 (RuntimeObject* p1, AREnvironmentProbesChangedEvent_t8757E98E11F3D37F0CFC4589FCA5CD2107F8375C p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_387 (RuntimeObject* p1, ARFaceUpdatedEventArgs_tC20D17255858678A1A8230EA32D7C38287221FF6 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_388 (RuntimeObject* p1, ARFacesChangedEventArgs_tC05D4423CB2096FF5955C3A0A00056EE2B6301AE p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_389 (RuntimeObject* p1, ARHumanBodiesChangedEventArgs_t19088E0D3384A22C5D8A542957705222C834720B p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_390 (RuntimeObject* p1, ARMeshesChangedEventArgs_tE7A52D1E319626788F0990029A19823C3FA83903 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_391 (RuntimeObject* p1, AROcclusionFrameEventArgs_t50615B48D249629849B4157545F18620A4304E81 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_392 (RuntimeObject* p1, ARParticipantsChangedEventArgs_t2EAD9041A074A7ACEFF280662784747A4E85E527 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_393 (RuntimeObject* p1, ARPlaneBoundaryChangedEventArgs_tE59EDE94575C8947AD3F1F8DA1370D0A426A5FFC p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_394 (RuntimeObject* p1, ARPlanesChangedEventArgs_t8D63E0257BF9942EF8F8C0445F2FD46421017872 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_395 (RuntimeObject* p1, ARPointCloudChangedEventArgs_t7DE4CA4D30D369496221061F89CC4BF84E42CC1B p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_396 (RuntimeObject* p1, ARPointCloudUpdatedEventArgs_t9AC3E8FAC2452088DE276694AFE257D823EB79B4 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_397 (RuntimeObject* p1, ARRaycastUpdatedEventArgs_t4F200C75C97D91C3B96D3E6018CD31B9E9E19D6B p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_398 (RuntimeObject* p1, ARReferencePointsChangedEventArgs_t25F5471C71BDC45AB77834E2F331931EE37F7B62 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_399 (RuntimeObject* p1, ARSessionStateChangedEventArgs_tC31BD123D6B4F6168FB246762E79AB33962AE822 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_400 (RuntimeObject* p1, ARTrackablesParentTransformChangedEventArgs_tEF673BCB9382697300AE683ED29F0BF96E4A9C8A p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_401 (RuntimeObject* p1, ARTrackedImagesChangedEventArgs_tD7718E40EE25D22E9143DA4F556C44980E18BE2F p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_402 (RuntimeObject* p1, ARTrackedObjectsChangedEventArgs_t378A63B91AD22EA4BA9C68805C72DDA4B7C01509 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_403 (RuntimeObject* p1, ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF p2, ArConfig_tC991F7E3046E638B111BDBE5A2B25C4F363C4F1C p3, intptr_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_404 (RuntimeObject* __this, RuntimeObject* p1, BoundedPlane_tF51C315A8961EB42F0A1B60D47158646E5AF75CE p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_405 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_405 (RuntimeObject* p1, uint8_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_406 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_407 (RuntimeObject* __this, RuntimeObject* p1, uint8_t p2, DebugScreenCapture_t859E4E87C94587A08893C726D4FF84BD8F288CC5 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_407 (RuntimeObject* p1, uint8_t p2, DebugScreenCapture_t859E4E87C94587A08893C726D4FF84BD8F288CC5 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_408 (RuntimeObject* p1, uint8_t p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_409 (RuntimeObject* p1, CullingGroupEvent_tC79BA328A8280C29F6002F591614081A0E87D110 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_410 (RuntimeObject* p1, InputDevice_t882EE3EE8A71D8F5F38BA3F9356A49F24510E8BD p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_411 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_411 (void* __this, RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_411 (RuntimeObject* p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_412 (RuntimeObject* __this, RuntimeObject* p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_412 (RuntimeObject* p1, int32_t p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_413 (RuntimeObject* p1, int32_t p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_414 (RuntimeObject* p1, int32_t p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_415 (RuntimeObject* p1, int32_t p2, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p3, NativeArray_1_t81F55263465517B73C455D3400CF67B4BADD85CF p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_416 (RuntimeObject* p1, int32_t p2, ConversionParams_t062706B15E2C508C54473A1FD72013C4381CCB62 p3, intptr_t p4, int32_t p5, intptr_t p6, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4,&p5,&p6};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_417 (RuntimeObject* __this, RuntimeObject* p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_417 (RuntimeObject* p1, intptr_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_418 (RuntimeObject* p1, intptr_t p2, ArSession_t5038012861AFE90255CCD3F97A7819940B50ECFF p3, ArCameraConfigFilter_tF665AEAE3CDEB76E6485508096A093A9E0E0B607 p4, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_419 (RuntimeObject* __this, RuntimeObject* p1, intptr_t p2, intptr_t p3, RuntimeObject* p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,p4,&p5};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_419 (RuntimeObject* p1, intptr_t p2, intptr_t p3, RuntimeObject* p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3,p4,&p5};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_420 (RuntimeObject* p1, MeshGenerationResult_tD5A6D639B2CF1A3F855AFB41861DEC48DC0D3A9C p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_421 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_421 (void* __this, RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_421 (RuntimeObject* p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {p1,p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_422 (RuntimeObject* p1, RuntimeObject* p2, NativeArray_1_tDF6A1978B5813BF4DAD7948E398009FFC9BEA38D p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_423 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_423 (RuntimeObject* p1, RuntimeObject* p2, uint8_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_424 (RuntimeObject* p1, RuntimeObject* p2, uint8_t p3, DebugScreenCapture_t859E4E87C94587A08893C726D4FF84BD8F288CC5 p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_425 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_425 (RuntimeObject* p1, RuntimeObject* p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_426 (RuntimeObject* p1, RuntimeObject* p2, int32_t p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_427 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4,&p5};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_428 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, int32_t p3, RuntimeObject* p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,p4,p5};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_429 (RuntimeObject* p1, RuntimeObject* p2, intptr_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_430 (RuntimeObject* p1, RuntimeObject* p2, intptr_t p3, intptr_t p4, RuntimeObject* p5, int32_t p6, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3,&p4,p5,&p6};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_431 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_431 (void* __this, RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_431 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_432 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, int32_t p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,&p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_433 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,p4};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_433 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,p4};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_434 (RuntimeObject* p1, RuntimeObject* p2, RuntimeObject* p3, RuntimeObject* p4, RuntimeObject* p5, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,p3,p4,p5};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_435 (RuntimeObject* __this, RuntimeObject* p1, RuntimeObject* p2, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_436 (RuntimeObject* p1, RuntimeObject* p2, uint32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_437 (RuntimeObject* p1, PhysicsScene_t55222DD37072E8560EE054A07C0E3FE391D9D9DE p2, NativeArray_1_tA04FF6E7BE3D24B3E6351C63BF7229421DFE1259 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_438 (RuntimeObject* p1, Scene_tA1DC762B79745EB5140F054C884855B922318356 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_439 (RuntimeObject* p1, Scene_tA1DC762B79745EB5140F054C884855B922318356 p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_440 (RuntimeObject* p1, Scene_tA1DC762B79745EB5140F054C884855B922318356 p2, Scene_tA1DC762B79745EB5140F054C884855B922318356 p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_441 (RuntimeObject* p1, float p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_442 (RuntimeObject* __this, RuntimeObject* p1, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_442 (RuntimeObject* p1, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_443 (RuntimeObject* __this, RuntimeObject* p1, uint32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_443 (RuntimeObject* p1, uint32_t p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedStaticCall_444 (RuntimeObject* p1, uint64_t p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2,p3};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_445 (RuntimeObject* __this, RuntimeObject* p1, XRAnchor_tDD427E66CAA09DE7B058EA76223EF7DC3880FE82 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_446 (RuntimeObject* __this, RuntimeObject* p1, XREnvironmentProbe_tAA657FAB648E2599B519F9FD66A1CEED65034DD9 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_447 (RuntimeObject* __this, RuntimeObject* p1, XRFace_t235F951F4AC7CC6A0CA6829CECA05210D64982FB p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_448 (RuntimeObject* __this, RuntimeObject* p1, XRHumanBody_t88EF91F599A4F22EABB233F85DE7782EE8B86692 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_449 (RuntimeObject* p1, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_450 (RuntimeObject* __this, RuntimeObject* p1, XRParticipant_t3885B841862D28B0509433D566F00FA3C3CD79E1 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_451 (RuntimeObject* __this, RuntimeObject* p1, XRPointCloud_t99DB921A9C92F53CEA3EB29A64E2DECDA6EA7D8C p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_452 (RuntimeObject* __this, RuntimeObject* p1, XRRaycast_t100015712885CDF4EF42820EB36277DC6DDC8103 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_453 (RuntimeObject* __this, RuntimeObject* p1, XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_454 (RuntimeObject* __this, RuntimeObject* p1, XRReferencePoint_t7B269D148483373FDE78B3262CF334C2D86B6291 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_455 (RuntimeObject* __this, RuntimeObject* p1, XRTrackedImage_t0F99DAB96B2D6422D0F8DA720F9BEFD3655DDFDD p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_456 (RuntimeObject* __this, RuntimeObject* p1, XRTrackedObject_t56B5A101A8698B5C95F2CBE93FCF0F8911B67E75 p2, const RuntimeMethod* method)
{
	void* args[] = {p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_457 (RuntimeObject* __this, PhysicsScene_t55222DD37072E8560EE054A07C0E3FE391D9D9DE p1, NativeArray_1_tA04FF6E7BE3D24B3E6351C63BF7229421DFE1259 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_457 (PhysicsScene_t55222DD37072E8560EE054A07C0E3FE391D9D9DE p1, NativeArray_1_tA04FF6E7BE3D24B3E6351C63BF7229421DFE1259 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_458 (RuntimeObject* __this, Scene_tA1DC762B79745EB5140F054C884855B922318356 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_458 (Scene_tA1DC762B79745EB5140F054C884855B922318356 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_459 (RuntimeObject* __this, Scene_tA1DC762B79745EB5140F054C884855B922318356 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_459 (Scene_tA1DC762B79745EB5140F054C884855B922318356 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_460 (RuntimeObject* __this, Scene_tA1DC762B79745EB5140F054C884855B922318356 p1, Scene_tA1DC762B79745EB5140F054C884855B922318356 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_460 (Scene_tA1DC762B79745EB5140F054C884855B922318356 p1, Scene_tA1DC762B79745EB5140F054C884855B922318356 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_461 (RuntimeObject* __this, ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36 p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_462 (RuntimeObject* __this, ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36 p1, RuntimeObject* p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2,p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_463 (RuntimeObject* __this, float p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_463 (float p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_464 (RuntimeObject* __this, StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_464 (StreamingContext_t56760522A751890146EE45F82F866B55B7E33677 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_465 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_466 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, int32_t p2, RuntimeObject* p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_467 (RuntimeObject* __this, TypedReference_tF20A82297BED597FD80BDA0E41F74746B0FD642B p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_468 (RuntimeObject* __this, uint16_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_469 (RuntimeObject* __this, uint32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedInstanceCall_469 (void* __this, uint32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_470 (RuntimeObject* __this, uint64_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_471 (RuntimeObject* __this, uint64_t p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_471 (uint64_t p1, RuntimeObject* p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,p2};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_472 (RuntimeObject* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 p1, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 p2, int32_t p3, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2,&p3};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_473 (RuntimeObject* __this, XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedStaticCall_473 (XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, NULL);
}
static  void UnresolvedVirtualCall_474 (RuntimeObject* __this, XRSessionUpdateParams_t7E03F47CA8C7ACECDA528B8F260C2EDD9D1C12F1 p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  void UnresolvedVirtualCall_475 (RuntimeObject* __this, XRSessionUpdateParams_t7E03F47CA8C7ACECDA528B8F260C2EDD9D1C12F1 p1, Configuration_tF3E68F5793D5A997146A65AEAAC9B062BCAF0947 p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, NULL);
}
static  VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC UnresolvedVirtualCall_476 (RuntimeObject* __this, const RuntimeMethod* method)
{
	VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC UnresolvedInstanceCall_476 (void* __this, const RuntimeMethod* method)
{
	VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC UnresolvedStaticCall_476 (const RuntimeMethod* method)
{
	VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC UnresolvedVirtualCall_477 (RuntimeObject* __this, RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC UnresolvedStaticCall_477 (RuntimeObject* p1, const RuntimeMethod* method)
{
	void* args[] = {p1};
	VoidTaskResult_t73B628B764C6668DAAAE2D37BD6FC07BCA27A5AC il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_direct_method_pointer(method), method, NULL, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A UnresolvedVirtualCall_478 (RuntimeObject* __this, const RuntimeMethod* method)
{
	XRNodeState_t683158812A1D80A6BC73DB97405BB0B795A9111A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  XRPointCloudData_t06BF6FA78C7ED8CBDCAAAFAC6548A309860E7C5B UnresolvedVirtualCall_479 (RuntimeObject* __this, TrackableId_t49EAE8AA4B9584E314518723DC22B66496D47AD7 p1, int32_t p2, const RuntimeMethod* method)
{
	void* args[] = {&p1,&p2};
	XRPointCloudData_t06BF6FA78C7ED8CBDCAAAFAC6548A309860E7C5B il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F UnresolvedVirtualCall_480 (RuntimeObject* __this, const RuntimeMethod* method)
{
	XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F UnresolvedVirtualCall_481 (RuntimeObject* __this, int32_t p1, const RuntimeMethod* method)
{
	void* args[] = {&p1};
	XRReferenceImage_tB2544D6E18E55CD44F4EED1B0573A6A7154C1E2F il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, args, &il2cppRetVal);
	return il2cppRetVal;
}
static  XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 UnresolvedVirtualCall_482 (RuntimeObject* __this, const RuntimeMethod* method)
{
	XRReferenceObject_tDC04E77BBDCC6428C8B852A7CF1208DD2AF9AE14 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 UnresolvedVirtualCall_483 (RuntimeObject* __this, const RuntimeMethod* method)
{
	OrderBlock_t62FD6F6544F34B5298DEF2F77AAE446F269B7837 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A UnresolvedVirtualCall_484 (RuntimeObject* __this, const RuntimeMethod* method)
{
	RenderRequest_t432931B06439AC4704282E924DE8A9A474DB6B9A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC UnresolvedVirtualCall_485 (RuntimeObject* __this, const RuntimeMethod* method)
{
	SingleRange_tB50C1C2B62BDC445BDBA41FD3CDC77A45A211BBC il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A UnresolvedVirtualCall_486 (RuntimeObject* __this, const RuntimeMethod* method)
{
	PoseData_t67ECD1DA6257206C1935CCD030E1E1EF57E1443A il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
static  WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 UnresolvedVirtualCall_487 (RuntimeObject* __this, const RuntimeMethod* method)
{
	WorkRequest_t8AF542F2E248D9234341817CDB5F76C27D348B44 il2cppRetVal;
	method->invoker_method(il2cpp_codegen_get_method_pointer(method), method, __this, NULL, &il2cppRetVal);
	return il2cppRetVal;
}
IL2CPP_EXTERN_C const Il2CppMethodPointer g_UnresolvedVirtualMethodPointers[];
const Il2CppMethodPointer g_UnresolvedVirtualMethodPointers[488] = 
{
	(const Il2CppMethodPointer)UnresolvedVirtualCall_0,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_1,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_2,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_3,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_4,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_5,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_6,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_7,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_8,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_9,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_10,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_11,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_12,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_13,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_14,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_15,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_16,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_17,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_18,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_19,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_20,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_21,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_22,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_23,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_24,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_25,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_26,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_27,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_28,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_29,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_30,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_31,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_32,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_33,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_34,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_35,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_36,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_37,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_38,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_39,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_40,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_41,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_42,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_43,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_44,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_45,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_46,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_47,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_48,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_49,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_50,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_51,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_52,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_53,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_54,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_55,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_56,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_57,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_58,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_59,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_60,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_61,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_62,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_63,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_64,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_65,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_66,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_67,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_68,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_69,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_70,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_71,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_72,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_73,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_74,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_78,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_80,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_82,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_83,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_84,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_96,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_97,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_98,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_99,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_100,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_101,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_102,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_103,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_104,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_105,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_106,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_107,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_108,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_109,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_110,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_111,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_112,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_113,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_114,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_115,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_116,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_117,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_118,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_119,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_120,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_121,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_122,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_123,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_124,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_125,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_126,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_127,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_128,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_129,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_130,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_131,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_132,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_133,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_134,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_135,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_136,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_137,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_138,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_139,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_140,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_141,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_142,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_143,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_144,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_145,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_146,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_147,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_148,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_149,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_150,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_151,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_152,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_153,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_154,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_155,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_156,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_157,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_158,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_159,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_160,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_161,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_162,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_163,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_164,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_165,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_166,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_167,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_168,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_169,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_170,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_171,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_172,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_173,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_174,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_175,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_176,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_177,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_178,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_179,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_180,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_181,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_183,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_185,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_187,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_188,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_190,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_191,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_192,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_193,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_194,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_195,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_196,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_197,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_198,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_199,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_200,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_201,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_202,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_203,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_205,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_206,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_207,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_208,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_211,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_213,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_215,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_217,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_219,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_221,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_223,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_225,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_227,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_229,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_231,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_233,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_234,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_235,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_236,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_237,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_238,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_239,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_240,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_241,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_242,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_243,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_244,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_245,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_246,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_247,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_248,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_249,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_250,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_251,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_252,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_253,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_254,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_255,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_256,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_257,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_258,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_259,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_260,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_261,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_262,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_263,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_264,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_265,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_266,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_268,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_269,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_270,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_271,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_272,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_273,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_274,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_275,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_276,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_277,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_278,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_279,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_281,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_282,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_283,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_284,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_285,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_286,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_287,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_288,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_289,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_290,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_291,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_292,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_294,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_295,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_297,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_300,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_301,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_303,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_304,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_305,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_306,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_307,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_308,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_309,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_310,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_311,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_312,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_314,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_315,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_316,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_317,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_318,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_319,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_320,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_321,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_322,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_323,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_324,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_325,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_326,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_327,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_328,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_329,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_330,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_331,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_332,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_333,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_334,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_335,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_336,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_337,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_338,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_339,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_340,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_341,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_342,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_343,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_344,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_345,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_346,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_347,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_348,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_349,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_350,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_351,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_352,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_353,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_354,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_355,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_356,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_357,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_358,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_359,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_360,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_361,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_362,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_363,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_364,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_365,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_366,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_367,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_368,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_369,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_370,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_371,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_372,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_373,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_374,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_375,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_376,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_377,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_378,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_379,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_404,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_405,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_406,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_407,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_411,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_412,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_417,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_419,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_421,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_423,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_425,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_427,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_428,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_431,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_433,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_435,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_442,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_443,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_445,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_446,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_447,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_448,
	NULL,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_450,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_451,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_452,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_453,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_454,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_455,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_456,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_457,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_458,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_459,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_460,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_461,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_462,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_463,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_464,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_465,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_466,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_467,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_468,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_469,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_470,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_471,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_472,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_473,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_474,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_475,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_476,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_477,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_478,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_479,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_480,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_481,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_482,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_483,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_484,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_485,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_486,
	(const Il2CppMethodPointer)UnresolvedVirtualCall_487,
};
IL2CPP_EXTERN_C const Il2CppMethodPointer g_UnresolvedInstanceMethodPointers[];
const Il2CppMethodPointer g_UnresolvedInstanceMethodPointers[488] = 
{
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_42,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_74,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_149,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_171,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_181,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_265,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_269,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_279,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_281,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_290,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_311,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_324,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_325,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_352,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_353,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_361,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_362,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_374,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_376,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_378,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_411,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_421,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_431,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_469,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedInstanceCall_476,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
IL2CPP_EXTERN_C const Il2CppMethodPointer g_UnresolvedStaticMethodPointers[];
const Il2CppMethodPointer g_UnresolvedStaticMethodPointers[488] = 
{
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_9,
	(const Il2CppMethodPointer)UnresolvedStaticCall_10,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_42,
	(const Il2CppMethodPointer)UnresolvedStaticCall_43,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_47,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_49,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_56,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_58,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_71,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_74,
	(const Il2CppMethodPointer)UnresolvedStaticCall_75,
	(const Il2CppMethodPointer)UnresolvedStaticCall_76,
	(const Il2CppMethodPointer)UnresolvedStaticCall_77,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_79,
	(const Il2CppMethodPointer)UnresolvedStaticCall_80,
	(const Il2CppMethodPointer)UnresolvedStaticCall_81,
	(const Il2CppMethodPointer)UnresolvedStaticCall_82,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_84,
	(const Il2CppMethodPointer)UnresolvedStaticCall_85,
	(const Il2CppMethodPointer)UnresolvedStaticCall_86,
	(const Il2CppMethodPointer)UnresolvedStaticCall_87,
	(const Il2CppMethodPointer)UnresolvedStaticCall_88,
	(const Il2CppMethodPointer)UnresolvedStaticCall_89,
	(const Il2CppMethodPointer)UnresolvedStaticCall_90,
	(const Il2CppMethodPointer)UnresolvedStaticCall_91,
	(const Il2CppMethodPointer)UnresolvedStaticCall_92,
	(const Il2CppMethodPointer)UnresolvedStaticCall_93,
	(const Il2CppMethodPointer)UnresolvedStaticCall_94,
	(const Il2CppMethodPointer)UnresolvedStaticCall_95,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_103,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_107,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_109,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_112,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_116,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_118,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_120,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_122,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_124,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_127,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_129,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_131,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_145,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_149,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_151,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_157,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_159,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_169,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_171,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_179,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_181,
	(const Il2CppMethodPointer)UnresolvedStaticCall_182,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_184,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_186,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_189,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_193,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_204,
	(const Il2CppMethodPointer)UnresolvedStaticCall_205,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_207,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_209,
	(const Il2CppMethodPointer)UnresolvedStaticCall_210,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_212,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_214,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_216,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_218,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_220,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_222,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_224,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_226,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_228,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_230,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_232,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_235,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_237,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_239,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_241,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_243,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_245,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_247,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_249,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_251,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_254,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_256,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_258,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_266,
	(const Il2CppMethodPointer)UnresolvedStaticCall_267,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_269,
	(const Il2CppMethodPointer)UnresolvedStaticCall_270,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_279,
	(const Il2CppMethodPointer)UnresolvedStaticCall_280,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_283,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_290,
	(const Il2CppMethodPointer)UnresolvedStaticCall_291,
	(const Il2CppMethodPointer)UnresolvedStaticCall_292,
	(const Il2CppMethodPointer)UnresolvedStaticCall_293,
	(const Il2CppMethodPointer)UnresolvedStaticCall_294,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_296,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_298,
	(const Il2CppMethodPointer)UnresolvedStaticCall_299,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_302,
	(const Il2CppMethodPointer)UnresolvedStaticCall_303,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_312,
	(const Il2CppMethodPointer)UnresolvedStaticCall_313,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_324,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_328,
	(const Il2CppMethodPointer)UnresolvedStaticCall_329,
	(const Il2CppMethodPointer)UnresolvedStaticCall_330,
	(const Il2CppMethodPointer)UnresolvedStaticCall_331,
	(const Il2CppMethodPointer)UnresolvedStaticCall_332,
	(const Il2CppMethodPointer)UnresolvedStaticCall_333,
	(const Il2CppMethodPointer)UnresolvedStaticCall_334,
	(const Il2CppMethodPointer)UnresolvedStaticCall_335,
	(const Il2CppMethodPointer)UnresolvedStaticCall_336,
	(const Il2CppMethodPointer)UnresolvedStaticCall_337,
	(const Il2CppMethodPointer)UnresolvedStaticCall_338,
	(const Il2CppMethodPointer)UnresolvedStaticCall_339,
	(const Il2CppMethodPointer)UnresolvedStaticCall_340,
	(const Il2CppMethodPointer)UnresolvedStaticCall_341,
	(const Il2CppMethodPointer)UnresolvedStaticCall_342,
	(const Il2CppMethodPointer)UnresolvedStaticCall_343,
	(const Il2CppMethodPointer)UnresolvedStaticCall_344,
	(const Il2CppMethodPointer)UnresolvedStaticCall_345,
	(const Il2CppMethodPointer)UnresolvedStaticCall_346,
	(const Il2CppMethodPointer)UnresolvedStaticCall_347,
	(const Il2CppMethodPointer)UnresolvedStaticCall_348,
	(const Il2CppMethodPointer)UnresolvedStaticCall_349,
	(const Il2CppMethodPointer)UnresolvedStaticCall_350,
	(const Il2CppMethodPointer)UnresolvedStaticCall_351,
	(const Il2CppMethodPointer)UnresolvedStaticCall_352,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_354,
	(const Il2CppMethodPointer)UnresolvedStaticCall_355,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_359,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_361,
	(const Il2CppMethodPointer)UnresolvedStaticCall_362,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_365,
	(const Il2CppMethodPointer)UnresolvedStaticCall_366,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_369,
	(const Il2CppMethodPointer)UnresolvedStaticCall_370,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_374,
	(const Il2CppMethodPointer)UnresolvedStaticCall_375,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_377,
	(const Il2CppMethodPointer)UnresolvedStaticCall_378,
	(const Il2CppMethodPointer)UnresolvedStaticCall_379,
	(const Il2CppMethodPointer)UnresolvedStaticCall_380,
	(const Il2CppMethodPointer)UnresolvedStaticCall_381,
	(const Il2CppMethodPointer)UnresolvedStaticCall_382,
	(const Il2CppMethodPointer)UnresolvedStaticCall_383,
	(const Il2CppMethodPointer)UnresolvedStaticCall_384,
	(const Il2CppMethodPointer)UnresolvedStaticCall_385,
	(const Il2CppMethodPointer)UnresolvedStaticCall_386,
	(const Il2CppMethodPointer)UnresolvedStaticCall_387,
	(const Il2CppMethodPointer)UnresolvedStaticCall_388,
	(const Il2CppMethodPointer)UnresolvedStaticCall_389,
	(const Il2CppMethodPointer)UnresolvedStaticCall_390,
	(const Il2CppMethodPointer)UnresolvedStaticCall_391,
	(const Il2CppMethodPointer)UnresolvedStaticCall_392,
	(const Il2CppMethodPointer)UnresolvedStaticCall_393,
	(const Il2CppMethodPointer)UnresolvedStaticCall_394,
	(const Il2CppMethodPointer)UnresolvedStaticCall_395,
	(const Il2CppMethodPointer)UnresolvedStaticCall_396,
	(const Il2CppMethodPointer)UnresolvedStaticCall_397,
	(const Il2CppMethodPointer)UnresolvedStaticCall_398,
	(const Il2CppMethodPointer)UnresolvedStaticCall_399,
	(const Il2CppMethodPointer)UnresolvedStaticCall_400,
	(const Il2CppMethodPointer)UnresolvedStaticCall_401,
	(const Il2CppMethodPointer)UnresolvedStaticCall_402,
	(const Il2CppMethodPointer)UnresolvedStaticCall_403,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_405,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_407,
	(const Il2CppMethodPointer)UnresolvedStaticCall_408,
	(const Il2CppMethodPointer)UnresolvedStaticCall_409,
	(const Il2CppMethodPointer)UnresolvedStaticCall_410,
	(const Il2CppMethodPointer)UnresolvedStaticCall_411,
	(const Il2CppMethodPointer)UnresolvedStaticCall_412,
	(const Il2CppMethodPointer)UnresolvedStaticCall_413,
	(const Il2CppMethodPointer)UnresolvedStaticCall_414,
	(const Il2CppMethodPointer)UnresolvedStaticCall_415,
	(const Il2CppMethodPointer)UnresolvedStaticCall_416,
	(const Il2CppMethodPointer)UnresolvedStaticCall_417,
	(const Il2CppMethodPointer)UnresolvedStaticCall_418,
	(const Il2CppMethodPointer)UnresolvedStaticCall_419,
	(const Il2CppMethodPointer)UnresolvedStaticCall_420,
	(const Il2CppMethodPointer)UnresolvedStaticCall_421,
	(const Il2CppMethodPointer)UnresolvedStaticCall_422,
	(const Il2CppMethodPointer)UnresolvedStaticCall_423,
	(const Il2CppMethodPointer)UnresolvedStaticCall_424,
	(const Il2CppMethodPointer)UnresolvedStaticCall_425,
	(const Il2CppMethodPointer)UnresolvedStaticCall_426,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_429,
	(const Il2CppMethodPointer)UnresolvedStaticCall_430,
	(const Il2CppMethodPointer)UnresolvedStaticCall_431,
	(const Il2CppMethodPointer)UnresolvedStaticCall_432,
	(const Il2CppMethodPointer)UnresolvedStaticCall_433,
	(const Il2CppMethodPointer)UnresolvedStaticCall_434,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_436,
	(const Il2CppMethodPointer)UnresolvedStaticCall_437,
	(const Il2CppMethodPointer)UnresolvedStaticCall_438,
	(const Il2CppMethodPointer)UnresolvedStaticCall_439,
	(const Il2CppMethodPointer)UnresolvedStaticCall_440,
	(const Il2CppMethodPointer)UnresolvedStaticCall_441,
	(const Il2CppMethodPointer)UnresolvedStaticCall_442,
	(const Il2CppMethodPointer)UnresolvedStaticCall_443,
	(const Il2CppMethodPointer)UnresolvedStaticCall_444,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_449,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_457,
	(const Il2CppMethodPointer)UnresolvedStaticCall_458,
	(const Il2CppMethodPointer)UnresolvedStaticCall_459,
	(const Il2CppMethodPointer)UnresolvedStaticCall_460,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_463,
	(const Il2CppMethodPointer)UnresolvedStaticCall_464,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_471,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_473,
	NULL,
	NULL,
	(const Il2CppMethodPointer)UnresolvedStaticCall_476,
	(const Il2CppMethodPointer)UnresolvedStaticCall_477,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
